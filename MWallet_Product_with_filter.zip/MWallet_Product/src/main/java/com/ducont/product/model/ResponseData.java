package com.ducont.product.model;

import com.ducont.core.model.BaseModel;

public class ResponseData extends BaseModel {

	private static final long serialVersionUID = 1L;

	private ResponseHeader header;

	private Object walletData;

	public ResponseHeader getHeader() {
		return header;
	}

	public void setHeader(ResponseHeader header) {
		this.header = header;
	}

	public Object getWalletData() {
		return walletData;
	}

	public void setWalletData(Object walletData) {
		this.walletData = walletData;
	}

}
