package com.ducont.product.rs.impl;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.model.Request;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.IRecurringWebService;
import com.ducont.recurring.payment.model.RecurringBillPayment;
import com.ducont.recurring.payment.model.RecurringBillPaymentRequest;
import com.ducont.recurring.payment.model.RecurringBillPaymentResponse;
import com.ducont.recurring.payment.model.RecurringFundsTransfer;
import com.ducont.recurring.payment.model.RecurringFundsTransferRequest;
import com.ducont.recurring.payment.model.RecurringFundsTransferResponse;
import com.ducont.recurring.payment.service.api.IRecurringBillPaymentService;
import com.ducont.recurring.payment.service.api.IRecurringFundsTransferService;
import com.ducont.recurring.payment.service.impl.RecurringBillPaymentServiceImpl;
import com.ducont.recurring.payment.service.impl.RecurringFundsTransferServiceImpl;

@Path("/recurring")
public class RecurringWebService extends BaseWebService implements IRecurringWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(RecurringWebService.class);

	@Path("funds-transfer")
	@POST
	public Response fundTransferDetails(Request request) {

		try {
			LOGGER.info("Fetch the fund transfer webservice begins.");

			RecurringFundsTransferRequest recurringFundsTransferRequest = (RecurringFundsTransferRequest) getRequestObject(
					request.getBody(), RecurringFundsTransferRequest.class);

			IRecurringFundsTransferService recurringFundsTransferService = new RecurringFundsTransferServiceImpl();
			RecurringFundsTransferResponse recurringFundsResponse = recurringFundsTransferService
					.getFundsTransferDetails(recurringFundsTransferRequest);

			LOGGER.info("Fetch the fund transfer webservice ends.");
			return constructSuccessResponse(recurringFundsResponse, "READ_RECURRING_FUND_TRANSFER_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the fund transfer webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("funds-transfer/add")
	@POST
	public Response createRecurringFundTransfer(Request request) {

		try {
			LOGGER.info("Adding new recurring fund transfer webservice begins.");

			RecurringFundsTransferRequest recurringFundsTransferRequest = (RecurringFundsTransferRequest) getRequestObject(
					request.getBody(), RecurringFundsTransferRequest.class);

			IRecurringFundsTransferService recurringFundsTransferService = new RecurringFundsTransferServiceImpl();
			RecurringFundsTransfer recurringFundsTransfer = recurringFundsTransferService
					.createRecurringFundTransfer(recurringFundsTransferRequest);

			LOGGER.info("Adding new recurring fund transfer webservice ends.");
			return constructSuccessResponse(recurringFundsTransfer, "ADD_RECURRING_FUND_TRANSFER_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Adding new recurring fund transfer webservice failed", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("bill-payment")
	@POST
	public Response billPaymentDetails(Request request) {

		try {
			LOGGER.info("Fetch the bill payment details webservice begins.");

			RecurringBillPaymentRequest recurringBillPaymentRequest = (RecurringBillPaymentRequest) getRequestObject(
					request.getBody(), RecurringBillPaymentRequest.class);

			IRecurringBillPaymentService recurringBillPaymentService = new RecurringBillPaymentServiceImpl();
			RecurringBillPaymentResponse recurringBillPayment = recurringBillPaymentService
					.getBillPaymentDetails(recurringBillPaymentRequest);

			LOGGER.info("Fetch the bill payment details webservice ends.");
			return constructSuccessResponse(recurringBillPayment, "READ_RECURRING_BILL_PAYMENT_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the bill payment details webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("bill-payment/add")
	@POST
	public Response createRecurringBillPayment(Request request) {

		try {
			LOGGER.info("Adding new recurring bill payment webservice begins.");

			RecurringBillPaymentRequest recurringBillPaymentRequest = (RecurringBillPaymentRequest) getRequestObject(
					request.getBody(), RecurringBillPaymentRequest.class);

			IRecurringBillPaymentService recurringBillPaymentService = new RecurringBillPaymentServiceImpl();
			RecurringBillPayment recurringBillPayment = recurringBillPaymentService
					.createRecurringBillPayment(recurringBillPaymentRequest);

			LOGGER.info("Adding new recurring bill payment webservice ends.");
			return constructSuccessResponse(recurringBillPayment, "ADD_RECURRING_BILL_PAYMENT_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Adding new recurring bill payment webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}
}