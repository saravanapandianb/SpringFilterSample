package com.ducont.product.rs.api;

import javax.ws.rs.core.Response;

import com.ducont.core.model.Request;

public interface IRecurringWebService {

	public Response fundTransferDetails(Request request);
	
	public Response createRecurringFundTransfer(Request request);
	
	public Response billPaymentDetails(Request request);
	
	public Response createRecurringBillPayment(Request request);
	
}
