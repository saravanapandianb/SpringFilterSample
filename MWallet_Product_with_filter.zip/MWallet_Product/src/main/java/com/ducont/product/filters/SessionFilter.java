package com.ducont.product.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response.Status;

import com.ducont.core.exception.AppException;
import com.ducont.core.model.Request;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SessionFilter extends BaseFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		if (!httpServletRequest.getPathInfo().startsWith("/mwallet")) {

			RequestWrapper requestWrapper = null;
			ResponseWrapper responseWrapper = null;
			Request walletRequest = null;

			requestWrapper = new RequestWrapper(httpServletRequest);
			responseWrapper = new ResponseWrapper(httpResponse);

			// Manipulating the request String to Request Object
			String requestBody = requestWrapper.getRequestString();
			GsonBuilder gsonBuilder = new GsonBuilder();
			gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			Gson gson = gsonBuilder.create();
			walletRequest = gson.fromJson(requestBody, Request.class);

			try {
				validateSession(walletRequest.getHeader());
			} catch (Exception e) {
				
				httpResponse.setHeader("messageCode", e.getMessage());
				throw new AppException(e);
			}
			
			chain.doFilter(requestWrapper, responseWrapper);

		} else {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
}
