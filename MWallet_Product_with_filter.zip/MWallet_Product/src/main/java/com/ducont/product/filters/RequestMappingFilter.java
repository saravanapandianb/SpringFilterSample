package com.ducont.product.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ducont.core.model.Request;
import com.ducont.core.util.StringUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class RequestMappingFilter extends BaseFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		
		if (!httpServletRequest.getPathInfo().startsWith("/mwallet")) {

			RequestWrapper requestWrapper = null;
			ResponseWrapper responseWrapper = null;
			String errorCode = "MSG_UNABLE_TO_PROCESS";
			Request walletRequest = null;
			boolean isServiceSuccess = false;

			try {

				requestWrapper = new RequestWrapper(httpServletRequest);
				responseWrapper = new ResponseWrapper(httpResponse);
				
				// Manipulating the request String to Request Object
				String requestBody = requestWrapper.getRequestString();
				GsonBuilder gsonBuilder = new GsonBuilder();
				gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
				Gson gson = gsonBuilder.create();
				walletRequest = getRequest(httpServletRequest, requestBody, Object.class);
				String requestStr = gson.toJson(walletRequest, Request.class);
				requestWrapper.setInputStream(requestStr);


				chain.doFilter(requestWrapper, responseWrapper);

				// Manipulating the response and construct the object
				String responseString = responseWrapper.getResponseContent();
				errorCode = responseWrapper.getHeader("messageCode");
				isServiceSuccess = Boolean.valueOf(responseWrapper.getHeader("serviceStatus"));

				if (isServiceSuccess) {
					// Success
					Object jsonElement = gson.fromJson(responseString, Object.class);
					responseString = constructSuccessResponse(walletRequest, jsonElement, errorCode);
				} else {
					// Failure
					responseString = constructFailureResponse(walletRequest, errorCode);
				}

				response.reset();
				response.getOutputStream().write(responseString.getBytes());

			} catch (Exception e) {

				if (responseWrapper != null) {
					errorCode = StringUtils.isNullOrEmpty(responseWrapper.getHeader("messageCode")) ? errorCode
							: responseWrapper.getHeader("messageCode");
				}
				
				String stringResponse = constructFailureResponse(walletRequest, errorCode);
				response.reset();
				response.getOutputStream().write(stringResponse.getBytes());
			}
		} else {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
}
