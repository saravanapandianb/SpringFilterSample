package com.ducont.product.rs.impl;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.billpayment.model.BillAmountRequest;
import com.ducont.billpayment.model.BillAmountResponse;
import com.ducont.billpayment.model.BillPaymentRequest;
import com.ducont.billpayment.model.BillPaymentResponse;
import com.ducont.billpayment.model.BillPaymentTransaction;
import com.ducont.billpayment.model.UpcomingBillPaymentRequest;
import com.ducont.billpayment.model.UpcomingBillPaymentResponse;
import com.ducont.billpayment.service.api.IBillPaymentService;
import com.ducont.billpayment.service.impl.BillPaymentServiceImpl;
import com.ducont.core.model.Request;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.IBillPaymentWebService;
import com.ducont.product.service.model.BillPaymentRequestWrapper;
import com.ducont.recurring.payment.service.api.IRecurringBillPaymentService;
import com.ducont.recurring.payment.service.impl.RecurringBillPaymentServiceImpl;

@Path("/bill-pay")
public class BillPaymentWebService extends BaseWebService implements IBillPaymentWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(BillPaymentWebService.class);

	@Path("recent-payments")
	@POST
	public Response recentPayments(Request request) {

		try {

			LOGGER.info("Fetch the recent payment webservice begins.");

			BillPaymentRequest billPaymentRequest = (BillPaymentRequest) getRequestObject(request.getBody(),
					BillPaymentRequest.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			List<BillPaymentTransaction> recentPayments = billPaymentService.getRecentPayments(billPaymentRequest);

			LOGGER.info("Fetch the recent payment webservice ends.");
			return constructSuccessResponse(recentPayments, "READ_RECENT_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Fetch the recent payment webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("upcoming-payments")
	@POST
	public Response upcomingPayments(Request request) {

		try {

			LOGGER.info("Fetch the upcoming payment webservice begins.");

			UpcomingBillPaymentRequest billPaymentRequest = (UpcomingBillPaymentRequest) getRequestObject(
					request.getBody(), UpcomingBillPaymentRequest.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			List<UpcomingBillPaymentResponse> upcomingPayments = billPaymentService
					.getUpcomingPayments(billPaymentRequest.getWalletId());

			LOGGER.info("Fetch the upcoming payment webservice ends.");
			return constructSuccessResponse(upcomingPayments, "READ_UPCOMING_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Fetch the upcoming payment webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("upcoming-payments/edit")
	@POST
	public Response editUpcomingPayment(Request request) {

		try {

			LOGGER.info("Upcoming payment edit webservice begins.");

			UpcomingBillPaymentRequest upcomingBillPaymentRequest = (UpcomingBillPaymentRequest) getRequestObject(
					request.getBody(), UpcomingBillPaymentRequest.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			Boolean editStatus = billPaymentService.editUpcomingPayment(upcomingBillPaymentRequest);

			LOGGER.info("Upcoming payment edit webservice ends.");
			return constructSuccessResponse(editStatus, "EDIT_UPCOMING_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Upcoming payment edit webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("upcoming-payments/delete")
	@POST
	public Response deleteUpcomingPayment(Request request) {

		try {

			LOGGER.info("Upcoming payment delete webservice begins.");

			UpcomingBillPaymentRequest upcomingBillPaymentRequest = (UpcomingBillPaymentRequest) getRequestObject(
					request.getBody(), UpcomingBillPaymentRequest.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			Boolean deleteStatus = billPaymentService.deleteUpcomingPayment(upcomingBillPaymentRequest);

			LOGGER.info("Upcoming payment delete webservice ends.");
			return constructSuccessResponse(deleteStatus, "DELETE_UPCOMING_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Upcoming payment delete webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("process-payment")
	@POST
	public Response processBillPayment(Request request) {

		try {

			LOGGER.info("Bill payment process webservice begins.");

			BillPaymentRequestWrapper billPaymentRequestWrapper = (BillPaymentRequestWrapper) getRequestObject(
					request.getBody(), BillPaymentRequestWrapper.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			BillPaymentResponse billPaymentResponse = billPaymentService
					.processBillPayment(billPaymentRequestWrapper.getBillPayment());

			// For add to Recurring
			if (billPaymentRequestWrapper.isRecurring()) {

				IRecurringBillPaymentService recurringBillPaymentService = new RecurringBillPaymentServiceImpl();
				recurringBillPaymentService
						.createRecurringBillPayment(billPaymentRequestWrapper.getRecurringBillPayment());
			}

			LOGGER.info("Bill payment process webservice ends.");
			return constructSuccessResponse(billPaymentResponse, "PROCESS_BILL_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Bill payment process webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("bill-amount")
	@POST
	public Response billAmount(Request request) {

		try {

			LOGGER.info("Fetch the billamount webservice begins.");

			BillAmountRequest billAmountRequest = (BillAmountRequest) getRequestObject(request.getBody(),
					BillAmountRequest.class);

			IBillPaymentService billPaymentService = new BillPaymentServiceImpl();
			BillAmountResponse amountResponse = billPaymentService.getBillAmount(billAmountRequest);

			LOGGER.info("Fetch the billamount webservice ends.");
			return constructSuccessResponse(amountResponse, "READ_BILL_AMOUNT_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Fetch the billamount webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}
}