package com.ducont.product.filters;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.json.JSONTokener;

import com.ducont.core.dao.api.IErrorMessage;
import com.ducont.core.dao.api.ISystemConfigDAO;
import com.ducont.core.dao.api.ITransLogDAO;
import com.ducont.core.dao.impl.ErrorMessageDAO;
import com.ducont.core.dao.impl.SystemConfigDAO;
import com.ducont.core.dao.impl.TransLogDAO;
import com.ducont.core.dao.impl.WalletInfoDAO;
import com.ducont.core.model.AuditLog;
import com.ducont.core.model.ErrorMessages;
import com.ducont.core.model.Request;
import com.ducont.core.model.RequestHeader;
import com.ducont.core.model.Wallet;
import com.ducont.core.util.EncryptionUtil;
import com.ducont.core.util.SessionUtil;
import com.ducont.product.model.Response;
import com.ducont.product.model.ResponseData;
import com.ducont.product.model.ResponseHeader;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class BaseFilter {

	public static final String REQUEST = "REQUEST";
	public static final String HEADER = "HEADER";
	public static final String BODY = "BODY";
	public static final String MWALLET_RESPONSE = "walletData";
	public static final String RESPONSE_HEADER = "header";

	public static final String SUCCESS_CODE = "0";
	public static final String ERROR_CODE = "105";
	public static final String SESSION_ERROR_CODE = "100";
	public static final String STATUS = "status";
	public static final String STATUSDESC = "statusdesc";
	public static final String token = "token";

	public static final String IS_SERVICE_SUCCESS = "isServiceSuccess";
	public static final String JSON_RESULT_SUCCESS = "result";

	public static final String serviceCode = "scode";
	public static final String deviceId = "did";
	public static final String appId = "appid";
	public static final String osVersion = "osvrsn";
	public static final String appVersion = "appvrsn";
	public static final String modelNumber = "model";
	public static final String sessionId = "sessid";
	public static final String language = "lang";
	public static final String ukey = "ukey";
	public static final String walletId = "wid";

	ITransLogDAO transDAO = new TransLogDAO();
	ISystemConfigDAO systemConfigDAO = new SystemConfigDAO();
	IErrorMessage errorMessagesDAO = new ErrorMessageDAO();

	protected String constructSuccessResponse(Request request, Object object, String errorCode) {

		GsonBuilder gsonBuilder = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		Gson gson = gsonBuilder.create();

		Response response = new Response();
		ResponseData result = new ResponseData();

		RequestHeader requestHeader = request.getHeader();
		ResponseHeader header = new ResponseHeader();

		// Header
		header.setStatus(SUCCESS_CODE);
		response.setServiceSuccess(true);

		// Read the error message from DB
		String errorStr = "";
		try {
			ErrorMessages errorMessage = errorMessagesDAO.getErrorMessage(errorCode, requestHeader.getLanguageId());
			errorStr = errorMessage.getErrorDescription();
		} catch (Exception e) {
			errorStr = "";
		}
		header.setStatusdesc(errorStr);

		header.setToken(requestHeader.getSessionId());
		header.setScode(requestHeader.getServiceCode() + "");

		// Response Data
		result.setHeader(header);
		result.setWalletData(object);

		response.setResult(result);

		// Construct response body
		String resultJson = gson.toJson(response);
		saveAuditLog(request, response);
		return resultJson;
	}

	protected String constructFailureResponse(Request request, String errorCode) {

		Gson gson = new Gson();
		JSONObject walletData = new JSONObject();

		Response response = new Response();
		ResponseData result = new ResponseData();

		RequestHeader requestHeader = request.getHeader();
		ResponseHeader header = new ResponseHeader();

		header.setStatus(ERROR_CODE);
		response.setServiceSuccess(false);

		// Read the error message from DB
		String errorStr = "";

		try {
			ErrorMessages errorMessage = null;

			if ("USER_SESSIONTIME_EXPIRED".equalsIgnoreCase(errorCode)) {
				header.setStatus(SESSION_ERROR_CODE);
			}
			
			errorMessage = errorMessagesDAO.getErrorMessage(errorCode, requestHeader.getLanguageId());
			errorStr = errorMessage.getErrorDescription();
		} catch (Exception e) {
			errorStr = "";
		}

		header.setStatusdesc(errorStr);
		header.setToken(requestHeader.getSessionId());
		header.setScode(requestHeader.getServiceCode() + "");

		// Response Data
		result.setHeader(header);
		result.setWalletData(walletData);

		response.setResult(result);

		saveAuditLog(request, response);

		// Construct response body
		String resultJson = gson.toJson(response);
		return resultJson;
	}

	protected Request getRequest(HttpServletRequest requestContext, String requestJson, Class<?> object) {

		JSONTokener tokener = new JSONTokener(requestJson);
		JSONObject jsonRequest = new JSONObject(tokener);
		JSONObject rootJson = jsonRequest.getJSONObject(REQUEST);
		JSONObject headerJson = rootJson.getJSONObject(HEADER);

		Request request = new Request();
		RequestHeader requestHeader = new RequestHeader();

		if (!headerJson.isNull(serviceCode)) {
			requestHeader.setServiceCode(headerJson.getInt(serviceCode));
		}
		if (!headerJson.isNull(deviceId)) {
			requestHeader.setDeviceId(headerJson.getString(deviceId));
		}
		if (!headerJson.isNull(appId)) {
			requestHeader.setAppId(headerJson.getString(appId));
		}
		if (!headerJson.isNull(modelNumber)) {
			requestHeader.setModelNumber(headerJson.getString(modelNumber));
		}
		if (!headerJson.isNull(osVersion)) {
			requestHeader.setOsVersion(headerJson.getString(osVersion));
		}
		if (!headerJson.isNull(appVersion)) {
			requestHeader.setAppVersion(headerJson.getString(appVersion));
		}
		if (!headerJson.isNull(sessionId)) {
			requestHeader.setSessionId(headerJson.getString(sessionId));
		}
		if (!headerJson.isNull(language)) {
			requestHeader.setLanguageId(headerJson.getString(language));
		}
		if (!headerJson.isNull(ukey)) {
			requestHeader.setUkeyId(headerJson.getString(ukey));
		}

		request.setRequestTime(new Date());
		request.setIpAddress(getIPAddress(requestContext));

		if (!headerJson.isNull(walletId)) {

			requestHeader.setWalletId(headerJson.getLong(walletId));
		}

		if (object != null) {

			if (!rootJson.isNull(BODY) && rootJson.getJSONObject(BODY) != null) {
				Object requestObject = constructRequest(rootJson.getJSONObject(BODY), object);
				request.setBody(requestObject);
			}
		}

		request.setHeader(requestHeader);
		return request;
	}

	protected Object constructRequest(JSONObject requestBody, Class<?> object) {

		Gson gson = new Gson();
		Object requestObject = gson.fromJson(requestBody.toString(), object);
		return requestObject;
	}

	protected String getIPAddress(HttpServletRequest requestContext) {

		String remoteAddr = requestContext.getRemoteAddr();
		if (remoteAddr.equalsIgnoreCase("0:0:0:0:0:0:0:1")) {
		    InetAddress inetAddress;
			try {
				inetAddress = InetAddress.getLocalHost();
				 String ipAddress = inetAddress.getHostAddress();
				 remoteAddr = ipAddress;
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		   
		}
		
		String x;
		if ((x = requestContext.getHeader("X-FORWARDED-FOR")) != null) {
			remoteAddr = x;
			int idx = remoteAddr.indexOf(',');
			if (idx > -1) {
				remoteAddr = remoteAddr.substring(0, idx);
			}
		}
		return remoteAddr;
	}
	
	protected String encryptRequest(String response) {

		return EncryptionUtil.encryptRequest(response, EncryptionUtil.getSecureToken());
	}

	protected String decryptRequest(String request) {

		return EncryptionUtil.decryptRequest(request);
	}
	
	protected void validateSession(RequestHeader requestHeader) throws Exception {

		try {
			
			SessionUtil sessionUtil = new SessionUtil();
			WalletInfoDAO walletInfoDAO = new WalletInfoDAO();
			Wallet wallet = walletInfoDAO.getWallet(requestHeader.getWalletId());

			sessionUtil.sessionTokenValidation(requestHeader, wallet.getMobileNumber());
			sessionUtil.updateSession(requestHeader, wallet.getMobileNumber());
			
			// Validate Service Status
			systemConfigDAO.getServiceByCode(requestHeader.getServiceCode());
		} catch (Exception e) {
			
			throw e;
		}
	}
	
	private AuditLog saveAuditLog(Request request, Response response) {

		AuditLog auditLog = new AuditLog();
		try {

			RequestHeader requestHeader = request.getHeader();
			ResponseData result = response.getResult();

			String requestJson = new Gson().toJson(request);
			String resultJson = new Gson().toJson(response);
			String statuDesc = result.getHeader().getStatusdesc();

			auditLog.setDeviceId(requestHeader.getDeviceId());
			auditLog.setModel(requestHeader.getModelNumber());
			auditLog.setOsVersion(requestHeader.getOsVersion());
			auditLog.setAppVersion(requestHeader.getAppVersion());
			auditLog.setAppId(Integer.parseInt(requestHeader.getAppId()));
			auditLog.setServiceId(requestHeader.getServiceCode());
			auditLog.setMobileNo(String.valueOf(requestHeader.getWalletId()));
			auditLog.setTransInTime(request.getRequestTime());
			auditLog.setTransOutTime(new Date());
			auditLog.setTransDesc(statuDesc);

			auditLog.setStatus(Integer.parseInt(result.getHeader().getStatus()));
			auditLog.setSystemIP(request.getIpAddress());
			auditLog.setRequest(requestJson);
			auditLog.setResponse(resultJson);

			transDAO.createAuditLog(auditLog);
		} catch (Exception e) {
			// Skip this error
		}
		return auditLog;

	}
}
