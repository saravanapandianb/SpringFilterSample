package com.ducont.product.rs.impl;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.model.Request;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.IQRCodeWebService;
import com.ducont.qrcode.model.QRCodeRequest;
import com.ducont.qrcode.model.QRCodeResponse;
import com.ducont.qrcode.model.QRCodeTransactionResponse;
import com.ducont.qrcode.model.ValidationResponse;
import com.ducont.qrcode.service.api.IQRCodeService;
import com.ducont.qrcode.service.impl.QRCodeServiceImpl;

@Path("/qrcode")
public class QRCodeWebService extends BaseWebService implements IQRCodeWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(QRCodeWebService.class);

	@Path("validate-mobile")
	@POST
	public Response validateMobile(Request request) {

		try {

			LOGGER.info("Validating the mobile number webservice begins...");

			QRCodeRequest qrCodeRequest = (QRCodeRequest) getRequestObject(request.getBody(), QRCodeRequest.class);

			IQRCodeService qrCodeService = new QRCodeServiceImpl();
			ValidationResponse qrCodeResponse = qrCodeService.validateMobileNumber(qrCodeRequest);

			LOGGER.info("Validating the mobile number webservice ends...");
			return constructSuccessResponse(qrCodeResponse, "VALIDATION_MOBILE_NUMBER_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Validating the mobile number webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("scan-pay")
	@POST
	public Response scanAndPay(Request request) {

		try {

			LOGGER.info("Scan & Pay webservice process begins...");

			QRCodeRequest qrCodeRequest = (QRCodeRequest) getRequestObject(request.getBody(), QRCodeRequest.class);

			IQRCodeService qrCodeService = new QRCodeServiceImpl();
			QRCodeResponse qrCodeResponse = qrCodeService.scanAndPay(qrCodeRequest, request.getHeader());

			LOGGER.info("Scan & Pay webservice process ends");
			return constructSuccessResponse(qrCodeResponse, "PAYMENT_SCAN_PAY_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Scan & Pay webservice process failed", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("scan-receive")
	@POST
	public Response scanAndReceive(Request request) {

		try {

			LOGGER.info("Scan & Receive webservice process begins...");

			QRCodeRequest qrCodeRequest = (QRCodeRequest) getRequestObject(request.getBody(), QRCodeRequest.class);

			IQRCodeService qrCodeService = new QRCodeServiceImpl();
			QRCodeResponse qrCodeResponse = qrCodeService.scanAndReceive(qrCodeRequest, request.getHeader());

			LOGGER.info("Scan & Receive webservice process ends");
			return constructSuccessResponse(qrCodeResponse, "PAYMENT_SCAN_RECEIVE_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Scan & Receive webservice process failed", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("recent-transactions")
	@POST
	public Response recentTransactions(Request request) {

		try {

			LOGGER.info("Fetch the recent transactions webservice process begins...");

			QRCodeRequest qrCodeRequest = (QRCodeRequest) getRequestObject(request.getBody(), QRCodeRequest.class);

			IQRCodeService qrCodeService = new QRCodeServiceImpl();
			QRCodeTransactionResponse transactionResponse = qrCodeService.recentTransactions(qrCodeRequest);

			LOGGER.info("Fetch the recent transactions webservice process ends");
			return constructSuccessResponse(transactionResponse, "READ_RECENT_QR_TRANSACTIONS_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the recent transactions webservice process failed", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("validate")
	@POST
	public Response validateQRCode(Request request) {

		try {

			LOGGER.info("Validate the QRCode webservice process begins...");

			QRCodeRequest qrCodeRequest = (QRCodeRequest) getRequestObject(request.getBody(), QRCodeRequest.class);

			IQRCodeService qrCodeService = new QRCodeServiceImpl();
			ValidationResponse validationResponse = qrCodeService.validateQRCode(qrCodeRequest);

			LOGGER.info("Validate the QRCode webservice process ends");
			return constructSuccessResponse(validationResponse, "VALIDATION_QRCODE_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Validate the QRCode webservice process failed", exception);
			return constructFailureResponse(exception);
		}
	}

}