/**
 * 
 */
package com.ducont.product.rs.impl;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import com.ducont.mwallet.restservices.RequestProcessor;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.IWalletWebService;

@Path("mwallet")
public class WalletWebServices extends BaseWebService implements IWalletWebService {

	@Path("handshake")
	@POST
	public String handShake(String inputRequest) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.handShake(inputRequest);
		return response;
	}

	@Path("register")
	@POST
	public String registration(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.registration(inputRequest, info, request);
		return response;
	}

	@Path("login")
	@POST
	public String login(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.login(inputRequest, request);
		return response;
	}

	@Path("changepin")
	@POST
	public String changepin(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.changepin(inputRequest, request);
		return response;
	}

	@Path("resetpin")
	@POST
	public String resetpin(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.resetpin(inputRequest, info, request);
		return response;
	}

	@Path("updateProfile")
	@POST
	public String updateProfile(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.updateProfile(inputRequest, request);
		return response;
	}

	@Path("getProfile")
	@POST
	public String getProfile(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getProfile(inputRequest, request);
		return response;
	}

	@Path("createWallet")
	@POST
	public String createWallet(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.createWallet(inputRequest, request);
		return response;
	}

	@Path("InitiateCardPayment")
	@POST
	public String InitiateCardPayment(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.InitiateCardPayment(inputRequest, request);
		return response;
	}

	@Path("InitiateSavedCardPayment")
	@POST
	public String initiateSavedCardPayment(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.initiateSavedCardPayment(inputRequest, request);
		return response;
	}

	@Path("InitiateSelfPayment")
	@POST
	public String InitiateSelfPayment(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.InitiateSelfPayment(inputRequest, info, request);
		return response;
	}

	@Path("getTransactionalHistory")
	@POST
	public String getTransactionalHistory(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getTransactionalHistory(inputRequest, request);
		return response;
	}

	@Path("sendmoney")
	@POST
	public String sendmoney(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.sendmoney(inputRequest, info, request);
		return response;

	}

	@Path("getOTP")
	@POST
	public String getOTP(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getOTP(inputRequest, request);
		return response;
	}

	@Path("validateOTP")
	@POST
	public String validateOTP(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.validateOTP(inputRequest, request);
		return response;
	}

	@Path("logout")
	@POST
	public String logout(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.logout(inputRequest, request);
		return response;
	}

	@Path("QRSendMoney")
	@POST
	public String qrSendMoney(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.qrSendMoney(inputRequest, request);
		return response;
	}

	@Path("getSaveCard")
	@POST
	public String getSaveCard(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getSaveCard(inputRequest, request);
		return response;
	}

	@Path("deleteSaveCard")
	@POST
	public String deleteSaveCard(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.deleteSaveCard(inputRequest, request);
		return response;
	}

	@Path("InitiateRequestMoney")
	@POST
	public String initiateRequestMoney(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.initiateRequestMoney(inputRequest, request);
		return response;
	}

	@Path("GetRequestMoney")
	@POST
	public String getRequestMoney(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getRequestMoney(inputRequest, request);
		return response;
	}

	@Path("ConfirmRequestMoney")
	@POST
	public String confirmRequestMoney(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.confirmRequestMoney(inputRequest, request);
		return response;
	}

	@Path("getIssue")
	@POST
	public String getIssue(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getIssue(inputRequest, request);
		return response;
	}

	@Path("raiseQuery")
	@POST
	public String raiseQuery(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.raiseQuery(inputRequest, request);
		return response;
	}

	@Path("saveFeedback")
	@POST
	public String saveFeedback(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.saveFeedback(inputRequest, request);
		return response;
	}

	@Path("getListRequest")
	@POST
	public String getListRequest(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getListRequest(inputRequest, request);
		return response;
	}

	@Path("initiateSplitBill")
	@POST
	public String initiateSplitBill(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.initiateSplitBill(inputRequest, request);
		return response;
	}

	@Path("getSplitBills")
	@POST
	public String getSplitBills(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getSplitBills(inputRequest, request);
		return response;
	}

	@Path("confirmSplitBill")
	@POST
	public String confirmSplitBill(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.confirmSplitBill(inputRequest, request);
		return response;
	}

	@Path("GetBillerCategory")
	@POST
	public String getBillerCategory(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getBillerCategory(inputRequest, request);
		return response;
	}

	@Path("GetBiller")
	@POST
	public String getBillerSubCategory(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getBillerSubCategory(inputRequest, request);
		return response;
	}

	@Path("PayBill")
	@POST
	public String getPayBill(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getPayBill(inputRequest, info, request);
		return response;
	}

	@Path("listIssueCategory")
	@POST
	public String listIssueCategory(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.listIssueCategory(inputRequest, request);
		return response;
	}

	@Path("ListAccounts")
	@POST
	public String listAccounts(String inputRequest, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.listAccounts(inputRequest, request);
		return response;
	}

	@Path("SendMoneyWalletToAccount")
	@POST
	public String sendMoneyWalletToAccount(String inputRequest, @Context UriInfo info,
			@Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.sendmoney(inputRequest, info, request);
		return response;
	}

	@Path("Detag")
	@POST
	public String detag(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.detag(inputRequest, info, request);
		return response;
	}

	@Path("UnRegister")
	@POST
	public String unRegistration(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.unRegistration(inputRequest, info, request);
		return response;
	}

	@Path("DownloadTransHistoryPDF")
	@POST
	public String getTransHistoryPDF(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request) {

		RequestProcessor requestProcessor = new RequestProcessor();
		String response = requestProcessor.getTransHistoryPDF(inputRequest, info, request);
		return response;
	}

}