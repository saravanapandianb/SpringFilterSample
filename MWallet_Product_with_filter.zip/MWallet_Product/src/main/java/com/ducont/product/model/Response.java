package com.ducont.product.model;

import com.ducont.core.model.BaseModel;

public class Response extends BaseModel {

	private static final long serialVersionUID = 1L;

	private boolean isServiceSuccess;

	private ResponseData result;

	public boolean isServiceSuccess() {
		return isServiceSuccess;
	}

	public void setServiceSuccess(boolean isServiceSuccess) {
		this.isServiceSuccess = isServiceSuccess;
	}

	public ResponseData getResult() {
		return result;
	}

	public void setResult(ResponseData result) {
		this.result = result;
	}
}
