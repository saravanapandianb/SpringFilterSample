package com.ducont.product.model;

import com.ducont.core.model.BaseModel;

public class UserBalance extends BaseModel {

	private static final long serialVersionUID = 1L;

	private String balanceAmount;

	public String getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(String balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

}
