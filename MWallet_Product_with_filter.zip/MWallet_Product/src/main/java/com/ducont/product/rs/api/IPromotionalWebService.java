package com.ducont.product.rs.api;

import javax.ws.rs.core.Response;

import com.ducont.core.model.Request;

public interface IPromotionalWebService {

	public Response offers(Request request);

	public Response promoCodes(Request request);

}
