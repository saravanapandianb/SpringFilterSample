package com.ducont.product.rs.impl;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.model.Request;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.ISocialPaymentWebService;
import com.ducont.social.code.model.SocialPayReceiveRequest;
import com.ducont.social.code.model.SocialPayReceiveResponse;
import com.ducont.social.code.model.SocialPaySendRequest;
import com.ducont.social.code.model.SocialPaySendResponse;
import com.ducont.social.code.service.api.ISocialPaymentService;
import com.ducont.social.code.service.impl.SocialPaymentServiceImpl;

@Path("/social-payment")
public class SocialPaymentWebService extends BaseWebService implements ISocialPaymentWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(SocialPaymentWebService.class);

	@Path("generate-send")
	@POST
	public Response generateSocialCodeAndSendMoney(Request request) {

		try {

			LOGGER.info("Generate social payment voucher code webservice begins.");

			SocialPaySendRequest socialPaySendRequest = (SocialPaySendRequest) getRequestObject(request.getBody(),
					SocialPaySendRequest.class);

			ISocialPaymentService socialPaymentService = new SocialPaymentServiceImpl();
			SocialPaySendResponse socialPaySendResponse = socialPaymentService
					.generateSocialCodeAndSendMoney(socialPaySendRequest, request.getHeader());

			LOGGER.info("Generate social payment voucher code webservice ends.");
			return constructSuccessResponse(socialPaySendResponse, "SOCIAL_CODE_GENERATION_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Generate social payment voucher code webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("apply-code")
	@POST
	public Response applySocialCode(Request request) {

		try {

			LOGGER.info("Apply social payment code webservice begins.");

			SocialPayReceiveRequest socialPayReceiveRequest = (SocialPayReceiveRequest) getRequestObject(
					request.getBody(), SocialPaySendRequest.class);

			ISocialPaymentService socialPaymentService = new SocialPaymentServiceImpl();
			SocialPayReceiveResponse applySocialPayResponse = socialPaymentService
					.applySocialCodeAndReceiveMoney(socialPayReceiveRequest, request.getHeader());

			LOGGER.info("Apply social payment code webservice ends.");
			return constructSuccessResponse(applySocialPayResponse, "APPLY_SOCIAL_CODE_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Apply social payment code webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}
}