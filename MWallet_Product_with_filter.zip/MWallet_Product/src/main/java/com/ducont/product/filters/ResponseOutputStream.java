package com.ducont.product.filters;

import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;

public class ResponseOutputStream extends ServletOutputStream {

    StringBuilder stringBuilder;

    public ResponseOutputStream() {
        this.stringBuilder = new StringBuilder();
    }

    @Override
    public void write(byte b[], int off, int len) throws IOException {
        stringBuilder.append(new String(b, off, len, "UTF-8"));
    }

    @Override
    public String toString() {
        return stringBuilder.toString();
    }

	@Override
	public void write(int b) throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isReady() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setWriteListener(WriteListener arg0) {
		// TODO Auto-generated method stub
		
	}
}
