package com.ducont.product.rs.api;

import javax.ws.rs.core.Response;

import com.ducont.core.model.Request;

public interface ISocialPaymentWebService {

	public Response generateSocialCodeAndSendMoney(Request request);

	public Response applySocialCode(Request request);

}
