package com.ducont.product.scheduler;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.social.code.scheduler.SocialPaymentReversalJob;

public class MWalletSchedulerListener implements ServletContextListener {

	private static Logger LOGGER = LoggerFactory.getLogger(MWalletSchedulerListener.class);

	private Scheduler scheduler;

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {

		try {

			LOGGER.info("Shutting down the schedulers started.");

			if (scheduler != null) {
				scheduler.shutdown();
			}

			LOGGER.info("Shutting down the schedulers completed.");
		} catch (SchedulerException e) {

			LOGGER.error("Error occurred while shutdown the schedulers.", e);
		}
	}

	@Override
	public void contextInitialized(ServletContextEvent ctx) {

		LOGGER.info("Initializing the schedulers started.");

		// Define the job and tie it to our SocialPaymentReversalJob class
		JobDetail job = JobBuilder.newJob(SocialPaymentReversalJob.class)
				.withIdentity("SocialPaymentReversalJob", "SocialPaymentReversalGroup").build();

		// Trigger the job on every day 12 am.
		Trigger trigger = TriggerBuilder.newTrigger()
				.withIdentity("SocialPaymentReversalTrigger", "SocialPaymentReversalGroup")
				.withSchedule(CronScheduleBuilder.cronSchedule("0 0 0 1/1 * ? *")).build();

		try {

			// Tell quartz to schedule the job using our trigger
			scheduler = ((StdSchedulerFactory) ctx.getServletContext()
					.getAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY)).getScheduler();
			scheduler.scheduleJob(job, trigger);

		} catch (SchedulerException e) {

			LOGGER.error("Error occurred while starting the schedulers.", e);
		}

		LOGGER.info("Initializing the schedulers completed.");
	}
}