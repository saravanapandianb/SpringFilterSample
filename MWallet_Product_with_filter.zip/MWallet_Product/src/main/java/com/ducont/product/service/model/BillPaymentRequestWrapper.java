package com.ducont.product.service.model;

import java.io.Serializable;

import com.ducont.billpayment.model.BillPaymentRequest;
import com.ducont.recurring.payment.model.RecurringBillPaymentRequest;

public class BillPaymentRequestWrapper implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	private BillPaymentRequest billPayment;

	private RecurringBillPaymentRequest recurringBillPayment;

	private boolean isFavourite;
	
	private boolean isRecurring;

	public BillPaymentRequest getBillPayment() {
		return billPayment;
	}

	public void setBillPayment(BillPaymentRequest billPayment) {
		this.billPayment = billPayment;
	}

	public RecurringBillPaymentRequest getRecurringBillPayment() {
		return recurringBillPayment;
	}

	public void setRecurringBillPayment(RecurringBillPaymentRequest recurringBillPayment) {
		this.recurringBillPayment = recurringBillPayment;
	}

	public boolean isFavourite() {
		return isFavourite;
	}

	public void setFavourite(boolean isFavourite) {
		this.isFavourite = isFavourite;
	}

	public boolean isRecurring() {
		return isRecurring;
	}

	public void setRecurring(boolean isRecurring) {
		this.isRecurring = isRecurring;
	}
}
