/**
 * 
 */
package com.ducont.product.rs.impl;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.model.Request;
import com.ducont.offers.promocodes.model.OfferRequest;
import com.ducont.offers.promocodes.model.OfferResponse;
import com.ducont.offers.promocodes.model.PromoCodeRequest;
import com.ducont.offers.promocodes.model.PromoCodeResponse;
import com.ducont.offers.promocodes.service.impl.OfferServiceImpl;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.IPromotionalWebService;

@Path("/promotion")
public class PromotionalWebService extends BaseWebService implements IPromotionalWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(PromotionalWebService.class);

	@Path("offers")
	@POST
	public Response offers(Request request) {

		try {

			LOGGER.info("Fetch the offers webservice begins.");

			OfferRequest offerRequest = (OfferRequest) getRequestObject(request.getBody(), OfferRequest.class);
			OfferResponse offerResponse = new OfferServiceImpl().getOfferList(offerRequest);

			LOGGER.info("Fetch the offers webservice ends.");
			return constructSuccessResponse(offerResponse, "READ_OFFERS_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the offers webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

	@Path("promocodes")
	@POST
	public Response promoCodes(Request request) {

		try {

			LOGGER.info("Fetch the promocodes webservice begins.");

			PromoCodeRequest promoCodeRequest = (PromoCodeRequest) getRequestObject(request.getBody(),
					PromoCodeRequest.class);
			PromoCodeResponse promoCodeResponse = new OfferServiceImpl().getPromoList(promoCodeRequest);

			LOGGER.info("Fetch the promocodes webservice ends.");
			return constructSuccessResponse(promoCodeResponse, "READ_PROMOCODES_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the promocodes webservice failed.", exception);
			return constructFailureResponse(exception);
		}
	}

}