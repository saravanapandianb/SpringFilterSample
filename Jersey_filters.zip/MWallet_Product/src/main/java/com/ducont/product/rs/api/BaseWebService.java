package com.ducont.product.rs.api;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.ducont.core.exception.AppException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

public class BaseWebService {

	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	protected Object getRequestObject(Object requestBody, Class<?> object) {

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
	        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
	        @Override
	        public Date deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context)
	                throws JsonParseException {
	            try {
	                return df.parse(json.getAsString());
	            } catch (ParseException e) {
	                return null;
	            }
	        }
	    });
		Gson gson = gsonBuilder.create();
		JsonElement jsonElement = gson.toJsonTree(requestBody);
		Object requestObject = gson.fromJson(jsonElement, object);
		return requestObject;
	}
	
	protected Response constructSuccessResponse(Object responseObject, String responseMessage) {

		GsonBuilder gsonBuilder = new GsonBuilder().setDateFormat(DATE_FORMAT);
		Gson gson = gsonBuilder.create();
		String responseObjStr = gson.toJson(responseObject);
		
		return javax.ws.rs.core.Response.status(Status.OK).entity(responseObjStr).header("messageCode", responseMessage)
				.header("serviceStatus", true).build();
	}

	protected Response constructFailureResponse(Exception exception) {

		String errorStr = null;
		if (exception instanceof AppException) {

			errorStr = exception.getMessage();
		} else {
			errorStr = "MSG_UNABLE_TO_PROCESS";
		}

		return javax.ws.rs.core.Response.status(Status.OK).header("messageCode", errorStr)
				.header("serviceStatus", false).build();
	}
	
}
