package com.ducont.product.rs.api;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

public interface IWalletWebService {

	public String handShake(String inputRequest);
	
	public String registration(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String login(String inputRequest, @Context HttpServletRequest request);
	
	public String changepin(String inputRequest, @Context HttpServletRequest request);
	
	public String resetpin(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String updateProfile(String inputRequest, @Context HttpServletRequest request);
	
	public String getProfile(String inputRequest, @Context HttpServletRequest request);
	
	public String createWallet(String inputRequest, @Context HttpServletRequest request);
	
	public String InitiateCardPayment(String inputRequest, @Context HttpServletRequest request);
	
	public String initiateSavedCardPayment(String inputRequest, @Context HttpServletRequest request);
	
	public String InitiateSelfPayment(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String getTransactionalHistory(String inputRequest, @Context HttpServletRequest request);
	
	public String sendmoney(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String getOTP(String inputRequest, @Context HttpServletRequest request);
	
	public String validateOTP(String inputRequest, @Context HttpServletRequest request);
	
	public String logout(String inputRequest, @Context HttpServletRequest request);
	
	public String qrSendMoney(String inputRequest, @Context HttpServletRequest request);
	
	public String getSaveCard(String inputRequest, @Context HttpServletRequest request);
	
	public String deleteSaveCard(String inputRequest, @Context HttpServletRequest request);
	
	public String initiateRequestMoney(String inputRequest, @Context HttpServletRequest request);
	
	public String getRequestMoney(String inputRequest, @Context HttpServletRequest request);
	
	public String confirmRequestMoney(String inputRequest, @Context HttpServletRequest request);
	
	public String getIssue(String inputRequest, @Context HttpServletRequest request);
	
	public String raiseQuery(String inputRequest, @Context HttpServletRequest request);
	
	public String saveFeedback(String inputRequest, @Context HttpServletRequest request);
	
	public String getListRequest(String inputRequest, @Context HttpServletRequest request);
	
	public String initiateSplitBill(String inputRequest, @Context HttpServletRequest request);
	
	public String getSplitBills(String inputRequest, @Context HttpServletRequest request);
	
	public String confirmSplitBill(String inputRequest, @Context HttpServletRequest request);
	
	public String getBillerCategory(String inputRequest, @Context HttpServletRequest request);
	
	public String getBillerSubCategory(String inputRequest, @Context HttpServletRequest request);
	
	public String getPayBill(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String listIssueCategory(String inputRequest, @Context HttpServletRequest request);
	
	public String listAccounts(String inputRequest, @Context HttpServletRequest request);
	
	public String sendMoneyWalletToAccount(String inputRequest, @Context UriInfo info,
			@Context HttpServletRequest request);
	
	public String detag(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String unRegistration(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);
	
	public String getTransHistoryPDF(String inputRequest, @Context UriInfo info, @Context HttpServletRequest request);

}
