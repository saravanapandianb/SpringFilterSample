package com.ducont.product.model;

import com.ducont.core.model.BaseModel;

public class ResponseHeader extends BaseModel {

	private static final long serialVersionUID = 1L;
	
	private String status;
	private String statusdesc;
	private String token;
	private String scode;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusdesc() {
		return statusdesc;
	}

	public void setStatusdesc(String statusdesc) {
		this.statusdesc = statusdesc;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getScode() {
		return scode;
	}

	public void setScode(String scode) {
		this.scode = scode;
	}

}
