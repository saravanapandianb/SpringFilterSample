package com.ducont.product.rs.impl;

import java.util.HashMap;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.apache.commons.math3.util.Precision;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.dao.api.IBillerCategory;
import com.ducont.core.dao.api.IPaymentFrequency;
import com.ducont.core.dao.api.IWalletInfoDAO;
import com.ducont.core.dao.impl.BillerCategoryDAO;
import com.ducont.core.dao.impl.PaymentFrequencyDAO;
import com.ducont.core.dao.impl.WalletInfoDAO;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.BillerCategory;
import com.ducont.core.model.PaymentFrequency;
import com.ducont.core.model.Request;
import com.ducont.core.model.Wallet;
import com.ducont.product.rs.api.BaseWebService;
import com.ducont.product.rs.api.ICoreWebService;

@Path("/core")
public class CoreWebService extends BaseWebService implements ICoreWebService {

	private static Logger LOGGER = LoggerFactory.getLogger(CoreWebService.class);

	@Path("biller-categories")
	@POST
	public Response getBillerCategories(Request request) {

		try {

			LOGGER.info("Fetch the biller catagories webservice begins.");

			IBillerCategory billerCategoryDAO = new BillerCategoryDAO();
			List<BillerCategory> billerCategories = billerCategoryDAO.getBillerCategories();

			LOGGER.info("Fetch the biller catagories webservice ends.");
			return constructSuccessResponse(billerCategories, "READ_BILLER_CATEGORY_SUCCESS");

		} catch (Exception exception) {

			LOGGER.error("Fetch the biller catagories webservice failed.", exception);

			if (exception instanceof AppException) {

				return constructFailureResponse(exception);
			}

			return constructFailureResponse(new AppException("READ_BILLER_CATEGORY_FAILED"));
		}
	}

	@Path("payment-frequencies")
	@POST
	public Response getPaymentFrequencies(Request request) {

		try {

			LOGGER.info("Fetch the payment frequencies webservice begins.");

			IPaymentFrequency paymentFrequencyDAO = new PaymentFrequencyDAO();
			List<PaymentFrequency> paymentFrequencies = paymentFrequencyDAO.getPaymentFrequency();

			LOGGER.info("Fetch the payment frequencies webservice ends.");
			return constructSuccessResponse(paymentFrequencies, "READ_PAYMENT_FREQUENCY_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the payment frequencies webservice failed.", exception);

			if (exception instanceof AppException) {

				return constructFailureResponse(exception);
			}

			return constructFailureResponse(new AppException("READ_PAYMENT_FREQUENCY_FAILED"));
		}
	}

	@Path("user-balance")
	@POST
	public Response getUserBalance(Request request) {

		try {

			LOGGER.info("Fetch the user balance webservice begins.");

			IWalletInfoDAO walletInfoDAO = new WalletInfoDAO();
			Wallet wallet = walletInfoDAO.getWallet(request.getHeader().getWalletId());

			HashMap<String, String> userResponse = new HashMap<String, String>();
			userResponse.put("balanceAmount", String.format("%.3f", Precision.round(wallet.getBalanceAmount(), 3)));
			
			LOGGER.info("Fetch the user balance webservice ends.");
			return constructSuccessResponse(userResponse, "READ_USER_BALANCE_SUCCESS");
		} catch (Exception exception) {

			LOGGER.error("Fetch the user balance webservice failed.", exception);

			if (exception instanceof AppException) {

				return constructFailureResponse(exception);
			}

			return constructFailureResponse(new AppException("READ_USER_BALANCE_FAILED"));
		}
	}
}