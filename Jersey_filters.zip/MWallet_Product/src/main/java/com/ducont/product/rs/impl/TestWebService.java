package com.ducont.product.rs.impl;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.ducont.billpayment.model.BillAmountRequest;
import com.ducont.billpayment.model.BillPaymentResponse;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.Request;
import com.ducont.product.rs.api.BaseWebService;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

@Path("/test")
public class TestWebService extends BaseWebService {

	@Path("pay")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response testPay(Request request) {

		try {

			BillAmountRequest billPaymentRequest = (BillAmountRequest) getRequestObject(request.getBody(),
					BillAmountRequest.class);
			System.out.println(billPaymentRequest);

			BillPaymentResponse billResponse = new BillPaymentResponse();
			billResponse.setBalanceAmount("1000.30");
			System.out.println(billResponse);
			return constructSuccessResponse(billResponse, "READ_RECENT_PAYMENT_SUCCESS");

		} catch (Exception exception) {

			return constructFailureResponse(exception);
		}
	}

	@Path("pay2")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response testPay2(Request request) {

		try {

			Gson gson = new Gson();
			JsonElement jsonElement = gson.toJsonTree(request.getBody());
			BillAmountRequest billPaymentRequest = gson.fromJson(jsonElement, BillAmountRequest.class);
			System.out.println(billPaymentRequest);

			
			// if (billPaymentRequest != null) throw new Exception();
			 

			BillPaymentResponse billResponse = new BillPaymentResponse();
			billResponse.setBalanceAmount("1000.30");
			System.out.println(billResponse);

			return Response.status(Status.OK).entity(billResponse).header("messageCode", "READ_RECENT_PAYMENT_SUCCESS")
					.header("serviceStatus", true).build();
			
		} catch (Exception exception) {

			String errorStr = null;
			if (exception instanceof AppException) {

				errorStr = exception.getMessage();
			} else {
				errorStr = "MSG_UNABLE_TO_PROCESS";
			}

			return Response.status(Status.OK).header("messageCode", errorStr).header("serviceStatus", false).build();
		}
	}
}