package com.ducont.product.filters;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ducont.core.exception.AppException;
import com.ducont.core.model.Request;
import com.google.gson.Gson;

public class SessionFilter extends BaseFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		if (!httpServletRequest.getPathInfo().startsWith("/mwallet")) {

			RequestWrapper requestWrapper = null;
			ResponseWrapper responseWrapper = null;
			Request walletRequest = null;

			requestWrapper = new RequestWrapper(httpServletRequest);
			responseWrapper = new ResponseWrapper(httpResponse);

			// Manipulating the request String to Request Object
			String requestBody = requestWrapper.getRequestString();
			Gson gson = createGsonObject();
			walletRequest = gson.fromJson(requestBody, Request.class);
			String requestStr = gson.toJson(walletRequest, Request.class);
			requestWrapper.setInputStream(requestStr);
			
			try {
				validateSession(walletRequest.getHeader());
			} catch (Exception e) {
				
				httpResponse.setHeader("messageCode", e.getMessage());
				throw new AppException(e);
			}
			
			chain.doFilter(requestWrapper, responseWrapper);
			
			String responseString = responseWrapper.getResponseContent();
			response.getOutputStream().write(responseString.getBytes(StandardCharsets.UTF_8));

		} else {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
}
