package com.ducont.product.filters;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;

public class RequestWrapper extends HttpServletRequestWrapper {

	ServletInputStream servletInputStream = null;
	String requestString = null;
	
	public RequestWrapper(HttpServletRequest servletRequest) {
		super(servletRequest);

		try {
			String requestString = IOUtils.toString(servletRequest.getInputStream());
			servletInputStream = servletRequest.getInputStream();
			System.out.println(requestString);
			this.requestString = requestString;
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
    
	public String getRequestString() {
		
		return requestString;
	}

	public void setInputStream(String decryptedRequest) throws IOException {
		
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
				decryptedRequest.getBytes(StandardCharsets.UTF_8));
		ServletInputStream servletInputStream = new ServletInputStream() {
			public int read() throws IOException {
				return byteArrayInputStream.read();
			}

			@Override
			public boolean isFinished() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isReady() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public void setReadListener(ReadListener arg0) {
				// TODO Auto-generated method stub

			}
		};
		
		this.servletInputStream = servletInputStream;
	}
	
	@Override
	public ServletInputStream getInputStream() throws IOException {

		return servletInputStream;
	}
	
	@Override
    public String getHeader(String headerName) {
        String headerValue = super.getHeader(headerName);
        if ("Accept".equalsIgnoreCase(headerName)) {
            return  MediaType.APPLICATION_JSON;
        } else if ("Content-Type".equalsIgnoreCase(headerName)) {
            return MediaType.APPLICATION_JSON;
        }
        return headerValue;
    }
	
	@Override
	public Enumeration<String> getHeaders(String headerName) {

		Enumeration<String> headers = super.getHeaders(headerName);
		List<String> updatedHeaders = Collections.list(headers);
		
		for (int index = 0; index < updatedHeaders.size(); index++) {
			String headerValue = updatedHeaders.get(index);
			if ("Accept".equalsIgnoreCase(headerName) || "Content-Type".equalsIgnoreCase(headerName)) {
				headerValue = MediaType.APPLICATION_JSON;
				updatedHeaders.set(index, headerValue);
			}
		}
		
		return Collections.enumeration(updatedHeaders);
	}
}
