package com.ducont.product.rs.api;

import javax.ws.rs.core.Response;

import com.ducont.core.model.Request;

public interface IQRCodeWebService {

	public Response validateMobile(Request request);

	public Response scanAndPay(Request request);

	public Response scanAndReceive(Request request);

}
