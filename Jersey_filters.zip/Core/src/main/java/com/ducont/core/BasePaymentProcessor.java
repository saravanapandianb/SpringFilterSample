package com.ducont.core;

import java.util.Date;

import org.apache.commons.math3.util.Precision;

import com.ducont.core.AppName;
import com.ducont.core.dao.api.IWalletInfoDAO;
import com.ducont.core.dao.impl.WalletInfoDAO;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.RequestHeader;
import com.ducont.core.model.TransHistory;
import com.ducont.core.model.TransLog;
import com.ducont.core.model.Wallet;

public class BasePaymentProcessor {

	/**
	 * To construct the debit transaction history.
	 * 
	 * @param requestHeader
	 * @param transactionId
	 * @param transferAmount
	 * @param senderWallet
	 * @param receiverWallet
	 * @param description
	 * @return
	 */
	protected TransHistory constructTransHistoryDebit(RequestHeader requestHeader, long transactionId,
			double transferAmount, Wallet senderWallet, Wallet receiverWallet, String description) {

		TransHistory transHistorySender = new TransHistory();
		transHistorySender.setTransAmount(Precision.round(transferAmount, 3));
		transHistorySender.setServiceCode(requestHeader.getServiceCode());
		transHistorySender.setTransDate(new Date());
		transHistorySender.setTransCurrency("OMR");
		transHistorySender.setRemarks("TODO: Remark");
		transHistorySender.setTransReference(String.valueOf(transactionId));
		transHistorySender.setBalanceAmount(Precision.round(senderWallet.getBalanceAmount(), 3));
		transHistorySender.setWalletID(senderWallet.getWalletId());
		
		if(receiverWallet != null) {
			transHistorySender.setTransMobile(receiverWallet.getMobileNumber());
		}
		
		transHistorySender.setStatus('S');
		transHistorySender.setTransType('D');
		transHistorySender.setTransDescription(description);
		return transHistorySender;
	}
	
	/**
	 * To construct the credit transaction history.
	 * 
	 * @param requestHeader
	 * @param transactionId
	 * @param transferAmount
	 * @param senderWallet
	 * @param receiverWallet
	 * @param description
	 * @return
	 */
	protected TransHistory constructTransHistoryCredit(RequestHeader requestHeader, long transactionId,
			double transferAmount, Wallet senderWallet, Wallet receiverWallet, String description) {

		TransHistory transHistorySender = new TransHistory();
		transHistorySender.setTransAmount(Precision.round(transferAmount, 3));
		transHistorySender.setServiceCode(requestHeader.getServiceCode());
		transHistorySender.setTransDate(new Date());
		transHistorySender.setTransCurrency("OMR");
		transHistorySender.setRemarks("TODO: Remark");
		transHistorySender.setTransReference(String.valueOf(transactionId));
		transHistorySender.setBalanceAmount(Precision.round(receiverWallet.getBalanceAmount(), 3));
		transHistorySender.setWalletID(receiverWallet.getWalletId());
		
		if(senderWallet != null) {
			transHistorySender.setTransMobile(senderWallet.getMobileNumber());
		}
		
		transHistorySender.setStatus('S');
		transHistorySender.setTransType('C');
		transHistorySender.setTransDescription(description);
		return transHistorySender;
	}

	/**
	 * To create the translog object for credit.
	 * 
	 * @param amount
	 * @param appId
	 * @param senderWallet
	 * @param receiverWallet
	 * @return
	 */
	protected TransLog constructTransLogCredit(double amount, String appId, Wallet senderWallet,
			Wallet receiverWallet) {

		TransLog transLogRequest = new TransLog();
		AppName appName = new AppName();
		String appNameValue = appName.getAppName(appId);

		if(senderWallet != null) {
			transLogRequest.setDebitWalletId(Long.toString(senderWallet.getWalletId()));
		}
		transLogRequest.setTransAmount(amount);
		
		if(receiverWallet != null) {
			transLogRequest.setCreditWalletId(String.valueOf(receiverWallet.getWalletId()));
		}
		
		transLogRequest.setTransCurrency("OMR");

		transLogRequest.setAppName(appNameValue);

		transLogRequest.setFlag('C');
		transLogRequest.setTransTime(new Date());
		transLogRequest.setStatus('N');
		return transLogRequest;
	}
	
	/**
	 * To create the translog object for debit.
	 * 
	 * @param amount
	 * @param appId
	 * @param senderWallet
	 * @param receiverWallet
	 * @return
	 */
	protected TransLog constructTransLogDebit(double amount, String appId, Wallet senderWallet,
			Wallet receiverWallet) {

		TransLog transLogRequest = new TransLog();
		AppName appName = new AppName();
		String appNameValue = appName.getAppName(appId);

		transLogRequest.setDebitWalletId(Long.toString(senderWallet.getWalletId()));
		transLogRequest.setTransAmount(amount);
		
		if(receiverWallet != null) {
			transLogRequest.setCreditWalletId(String.valueOf(receiverWallet.getWalletId()));
		}
		
		transLogRequest.setTransCurrency("OMR");

		transLogRequest.setAppName(appNameValue);

		transLogRequest.setFlag('D');
		transLogRequest.setTransTime(new Date());
		transLogRequest.setStatus('N');
		return transLogRequest;
	}

	/**
	 * To retrieve the wallet by wallet Id.
	 * 
	 * @param walletId
	 * @return
	 * @throws Exception
	 */
	protected Wallet getWallet(long walletId) throws Exception {

		IWalletInfoDAO walletInfoDAO = new WalletInfoDAO();
		Wallet wallet = walletInfoDAO.getWallet(walletId);

		if (wallet == null) {
			throw new AppException("USER_NOT_EXISTS_OR_INACTIVE");
		}

		return wallet;
	}

	/**
	 * To retrieve the wallet by wallet Id.
	 * 
	 * @param walletId
	 * @return
	 * @throws Exception
	 */
	protected Wallet getWallet(String mobileNumber) throws Exception {

		IWalletInfoDAO walletInfoDAO = new WalletInfoDAO();
		Wallet wallet = walletInfoDAO.getWallet(mobileNumber);

		if (wallet == null) {
			throw new AppException("USER_NOT_EXISTS_OR_INACTIVE");
		}

		return wallet;
	}

	/**
	 * To check the balance from the sender wallet.
	 * 
	 * @param wallet
	 * @param transferAmount
	 */
	protected void checkBalance(Wallet wallet, double transferAmount) {

		double balanceAmt = Precision.round(wallet.getBalanceAmount(), 3);
		double minBalAmt = Precision.round(wallet.getMinimumBalance(), 3);

		if ((balanceAmt - transferAmount) < minBalAmt) {

			throw new AppException("MSG_INSUFFICIENT_BALANCE");
		}
	}

	/**
	 * To update the sender and receiver wallet.
	 * 
	 * @param senderWallet
	 * @param receiverWallet
	 * @throws Exception
	 */
	protected void updateWallets(Wallet senderWallet, Wallet receiverWallet) throws Exception {

		IWalletInfoDAO walletInfoDAO = new WalletInfoDAO();
		walletInfoDAO.updateWallets(senderWallet, receiverWallet);
	}
	
	/**
	 * To update the wallet.
	 * 
	 * @param senderWallet
	 * @param receiverWallet
	 * @throws Exception
	 */
	protected void updateWallet(Wallet wallet) throws Exception {

		IWalletInfoDAO walletInfoDAO = new WalletInfoDAO();
		walletInfoDAO.updateWallet(wallet);
	}

	/**
	 * To debit the amount from user wallet.
	 * 
	 * @param wallet
	 * @param transferAmount
	 * @throws Exception
	 */
	protected void debitAmountFromSender(Wallet wallet, double transferAmount) throws Exception {

		double balanceAmt = Precision.round(wallet.getBalanceAmount(), 3);
		wallet.setBalanceAmount(Precision.round(balanceAmt - transferAmount, 3));
	}

	/**
	 * To credit the amount to the receiver wallet.
	 * 
	 * @param receiverWallet
	 * @param transferAmount
	 * @throws Exception
	 */
	protected void creditAmountToReceiver(Wallet receiverWallet, double transferAmount) throws Exception {

		double balanceAmt = Precision.round(receiverWallet.getBalanceAmount(), 3);
		receiverWallet.setBalanceAmount(Precision.round(balanceAmt + transferAmount, 3));
	}

	/**
	 * To retrieve the wallet by wallet Id.
	 * 
	 * @param walletId
	 * @return
	 */
	protected String formatBalanceAmount(double balance) {

		return String.valueOf(Precision.round(balance, 3));
	}
}
