package com.ducont.core.util;

import java.util.Date;

import com.ducont.core.dao.impl.SessionValidationDAO;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.CustomerToken;
import com.ducont.core.model.RequestHeader;

public class UniqueKeyValidation {

	public static boolean uniqueKeyValidation(RequestHeader requestHeader) {
		
		SessionValidationDAO sessionDAO = new SessionValidationDAO();
		CustomerToken customerToken = null;
		try {

			customerToken = sessionDAO.getUniqueKey(requestHeader.getDeviceId());
			
			if (customerToken != null) {
				
				if (!customerToken.getUniqueKey().equals(requestHeader.getUkeyId())) {
					
					sessionDAO.updateCustomerToken(customerToken);
				} else {
					
					 throw new AppException("MSG_REJECT_REQUEST");
				}
			} else {
				
				customerToken = preparesaveCustomerToken(requestHeader);
				sessionDAO.saveUniqueKey(customerToken);
			}
		} catch(AppException e) {
			
			throw e;
		} catch (Exception e) {
			
			throw new AppException("MSG_UNABLE_TO_PROCESS");
		}
		
		return true;
	}

	private static CustomerToken preparesaveCustomerToken(RequestHeader requestHeader) {
		
		CustomerToken custtoken = new CustomerToken();
		custtoken.setDeviceId(requestHeader.getDeviceId());
		custtoken.setUniqueKey(requestHeader.getUkeyId());
		custtoken.setUpdateTime(new Date());
		return custtoken;
	}
}
