package com.ducont.core;

public enum ErrorCode {

	UNKNOWN(0, "Unknown error has occured."),
	CONFIGURATION_LOADING_ISSUE(1, "Configuration loading issue."),
	DB_CONNECTION_ISSUE(2, "Database connection issue.");

	private final int code;
	private final String description;

	private ErrorCode(int code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public int getCode() {
		return code;
	}

	@Override
	public String toString() {
		return code + ": " + description;
	}
}
