package com.ducont.core.dao.impl;

import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.IWalletInfoDAO;
import com.ducont.core.model.Wallet;
import com.ducont.core.util.HibernateUtil;

public class WalletInfoDAO implements IWalletInfoDAO {

	private static Logger LOGGER = LoggerFactory.getLogger(WalletInfoDAO.class);

	@Override
	public Wallet getWallet(long walletId) throws Exception {

		LOGGER.info("Fetch the details for wallet : " + walletId + " Begins");
		Session session = null;
		Criteria criteria;
		Transaction transaction = null;
		Wallet wallet = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();

			criteria = session.createCriteria(Wallet.class);
			criteria.add(Restrictions.eq("walletId", walletId));
			criteria.add(Restrictions.eq("deleted", 'N'));
			criteria.add(Restrictions.eq("status", 'A'));
			wallet = (Wallet) criteria.uniqueResult();

			transaction.commit();
		} catch (Exception e) {

			if (transaction != null)
				transaction.rollback();
			LOGGER.error("Fetch the details for wallet : " + walletId + " failed.", e);
			throw new Exception("Fetch the details for wallet : " + walletId + " failed.", e);
		} finally {
			session.close();
		}

		LOGGER.info("Fetch the details for wallet : " + walletId + " ends");
		return wallet;
	}

	@Override
	public Wallet updateWallet(Wallet wallet) throws Exception {

		long walletId = wallet.getWalletId();
		LOGGER.info("Update the details for wallet : " + walletId + " Begins");
		Session session = null;
		Transaction transaction = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();
			wallet.setCurrentTransDate(new Date());
			session.update(wallet);
			transaction.commit();
		} catch (Exception e) {

			if (transaction != null) {
				transaction.rollback();
			}
			LOGGER.error("Update the details for wallet : " + walletId + " failed.", e);
			throw new Exception("Update the details for wallet : " + walletId + " failed.", e);
		} finally {

			session.close();
		}

		LOGGER.info("Update the details for wallet : " + walletId + " ends");
		return wallet;
	}

	@Override
	public Wallet getWallet(String mobileNumber) throws Exception {

		LOGGER.info("Fetch the details for wallet : " + mobileNumber + " Begins");
		Session session = null;
		Criteria criteria;
		Transaction transaction = null;
		Wallet wallet = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();

			criteria = session.createCriteria(Wallet.class);
			criteria.add(Restrictions.eq("mobileNumber", mobileNumber));
			criteria.add(Restrictions.eq("deleted", 'N'));
			criteria.add(Restrictions.eq("status", 'A'));
			wallet = (Wallet) criteria.uniqueResult();

			transaction.commit();
		} catch (Exception e) {

			if (transaction != null)
				transaction.rollback();
			LOGGER.error("Fetch the details for wallet : " + mobileNumber + " failed.", e);
			throw new Exception("Fetch the details for wallet : " + mobileNumber + " failed.", e);
		} finally {
			session.close();
		}

		LOGGER.info("Fetch the details for wallet : " + mobileNumber + " ends");
		return wallet;
	}

	@Override
	public void updateWallets(Wallet senderWallet, Wallet receiverWallet) throws Exception {

		long senderWalletId = senderWallet.getWalletId();
		long receiverWalletId = receiverWallet.getWalletId();

		LOGGER.info("Update the sender " + senderWalletId + "and receiver wallet " + receiverWalletId + "begins");
		Session session = null;
		Transaction transaction = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();
			senderWallet.setCurrentTransDate(new Date());
			receiverWallet.setCurrentTransDate(new Date());

			session.merge(senderWallet);
			session.merge(receiverWallet);
			transaction.commit();
		} catch (Exception e) {

			if (transaction != null) {
				transaction.rollback();
			}
			LOGGER.error("Update the sender " + senderWalletId + "and receiver wallet " + receiverWalletId + "begins",
					e);
			throw new Exception(
					"Update the sender " + senderWalletId + "and receiver wallet " + receiverWalletId + "begins", e);
		} finally {

			session.close();
		}

		LOGGER.info("Update the sender " + senderWalletId + "and receiver wallet " + receiverWalletId + "ends");
	}
}
