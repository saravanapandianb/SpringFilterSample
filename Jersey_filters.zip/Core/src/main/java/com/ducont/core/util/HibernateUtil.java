package com.ducont.core.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.exception.AppException;

public class HibernateUtil {

	private static Logger LOGGER = LoggerFactory.getLogger(HibernateUtil.class);

	private static HashMap<String, SessionFactory> sessionFactories = new HashMap<>();
	
	private static void createSessionFactory(String configFile) {
		
		LOGGER.info("Trying to create the hibernate session...");
		SessionFactory sessionFactory = null;
		try {

			Properties properties = EWalletUtil.getConfigurationProperties();
			
			// To decrypt password
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(properties.getProperty("Database.KEY"));
			encryptor.setAlgorithm(properties.getProperty("algorithm"));
			
			sessionFactory = new AnnotationConfiguration().configure(configFile)
					.setProperty("hibernate.connection.driver_class", properties.getProperty("connection.driver_class"))
					.setProperty("hibernate.connection.url", properties.getProperty("url"))
					.setProperty("hibernate.connection.username", properties.getProperty("username"))
					.setProperty("hibernate.connection.password", encryptor.decrypt(properties.getProperty("password")))
					.buildSessionFactory();
			
			sessionFactories.put(configFile, sessionFactory);
			
			LOGGER.info("Hibernate session created...");

		} catch (Exception ex) {

			LOGGER.error("Session creation failed due to error " + ex);
			throw new AppException("Session creation failed.", ex);
		}
	}

	/**
	 * To get the database session factory.
	 * 
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory(String configFile) {

		SessionFactory sessionFactory = null;
	    Iterator<String> itr = sessionFactories.keySet().iterator();
	    String configFileName = null;
	    
	    while(itr.hasNext()) {
	    	
	    	configFileName = itr.next();
	    	if(configFileName.equalsIgnoreCase(configFile)) {
	    		sessionFactory = sessionFactories.get(configFileName);
	    		break;
	    	}
	    }
	    
		if (sessionFactory == null) {
			createSessionFactory(configFile);
			sessionFactory = sessionFactories.get(configFile);
		}
		
		return sessionFactory;
	}

	/**
	 *  To close the already created sessionFactory.
	 */
	public static void shutdown() {
		
		LOGGER.info("Trying to close the hibernate session...");
		
		SessionFactory sessionFactory = null;
	    Iterator<String> itr = sessionFactories.keySet().iterator();
	    String configFileName = null;
	   
	    while(itr.hasNext()) {
	    	
	    	configFileName = itr.next();
    		sessionFactory = sessionFactories.get(configFileName);
    		sessionFactory.close();
	    }
		
		LOGGER.info("hibernate session closed successfully...");
	}
}