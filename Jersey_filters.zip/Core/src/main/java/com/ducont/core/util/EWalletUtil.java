package com.ducont.core.util;

import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.exception.AppException;

public class EWalletUtil {

	private static Logger LOGGER = LoggerFactory.getLogger(EWalletUtil.class);

	private static Properties properties;

	/**
	 * To load the configuration properties from the configured location.
	 * 
	 * @return Properties
	 */
	public static Properties getConfigurationProperties() {

		if (properties != null) {
			Enumeration<?> en = properties.propertyNames();
			return en.hasMoreElements() ? properties : loadConfiguration();
		} else {
			properties = loadConfiguration();
		}
		return properties;
	}

	private static Properties loadConfiguration() {

		LOGGER.info("Loading configuration properties...");

		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		Properties databaseProperties = null;
		Properties properties = null;

		try {

			String path = "C://Wallet_config//Param//Configuration.properties";//Constants.ENV_PROPERTIES_PATH + Constants.PROPERTIES_EXTENSION;
			ClassLoader loader = EWalletUtil.class.getClassLoader();
			if (loader != null) {

//				InputStream stream = loader.getResourceAsStream(path);
				FileInputStream stream = new FileInputStream(path);
				
				if (stream != null) {

					// To load the database properties and read the database alg and key
					properties = new Properties();
					properties.load(stream);

					encryptor.setPassword(properties.getProperty("Database.KEY"));
					encryptor.setAlgorithm(properties.getProperty("algorithm"));

					// To load the database properties
					databaseProperties = new EncryptableProperties(encryptor);
//					stream = loader.getResourceAsStream(path);
					stream = new FileInputStream(path);
					databaseProperties.load(stream);
				}/* else {

					LOGGER.error("Unable to load configuration properties from : " + path);
					throw new AppException("Unable to load the configuration properties from : " + path);
				}*/
			}

			LOGGER.info("Loaded configuration properties from: " + path);
		} catch (Exception e) {

			LOGGER.error("Exception while loading the configuration properties.", e.getMessage());
			throw new AppException("Exception while loading the configuration properties.", e);
		}

		properties = new Properties();
		Enumeration<?> en = databaseProperties.propertyNames();
		String key = null;
		while (en.hasMoreElements()) {

			key = (String) en.nextElement();
			properties.setProperty(key, databaseProperties.getProperty(key));
		}

		return properties;
	}
}
