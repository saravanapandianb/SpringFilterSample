package com.ducont.core.dao.api;

import com.ducont.core.model.Wallet;

public interface IWalletInfoDAO {

	public Wallet getWallet(long walletId) throws Exception;
	
	public Wallet updateWallet(Wallet wallet) throws Exception;
	
	public Wallet getWallet(String mobileNumber) throws Exception;
	
	public void updateWallets(Wallet senderWallet, Wallet receiverWallet) throws Exception;
}
