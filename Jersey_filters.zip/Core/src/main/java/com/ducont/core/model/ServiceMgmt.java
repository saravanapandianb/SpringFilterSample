/**
 * 
 */
package com.ducont.core.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ServiceMgmt")
public class ServiceMgmt implements Serializable {

	private static final long serialVersionUID = 8349157963753985627L;
	
	@Id
	@Column(name = "ServiceId")
	private int serviceId;

	@Column(name = "ServiceName")
	private String serviceName;

	@Column(name = "ServiceUrl")
	private String serviceUrl;

	@Column(name = "ServiceStatus")
	private char serviceStatus;

	@Column(name = "OTPReqd")
	private char otpReqd;

	@Column(name = "IsDeleted")
	private char isDeleted;

	@Column(name = "DisplayReqd")
	private char displayReqd;

	@Column(name = "AlertsReqd")
	private char alertsReqd;

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceUrl() {
		return serviceUrl;
	}

	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	public char getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(char serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public char getOtpReqd() {
		return otpReqd;
	}

	public void setOtpReqd(char otpReqd) {
		this.otpReqd = otpReqd;
	}

	public char getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(char isDeleted) {
		this.isDeleted = isDeleted;
	}

	public char getDisplayReqd() {
		return displayReqd;
	}

	public void setDisplayReqd(char displayReqd) {
		this.displayReqd = displayReqd;
	}

	public char getAlertsReqd() {
		return alertsReqd;
	}

	public void setAlertsReqd(char alertsReqd) {
		this.alertsReqd = alertsReqd;
	}

}
