package com.ducont.core.util;

import java.math.BigInteger;
import java.util.Arrays;

public class StringUtils {

	/**
	 * To convert bytes to string.
	 * 
	 * @param b
	 * @return String
	 */
	public static String bytesToString(byte[] b) {
		
		byte[] b2 = new byte[b.length + 1];
		b2[0] = 1;
		System.arraycopy(b, 0, b2, 1, b.length);
		return new BigInteger(b2).toString(36);
	}

	/**
	 * To convert the string to bytes.
	 * 
	 * @param s
	 * @return byte[]
	 */
	public static byte[] stringToBytes(String s) {
		
		byte[] b2 = new BigInteger(s, 36).toByteArray();
		return Arrays.copyOfRange(b2, 1, b2.length);
	}
	
	/**
	 * To check the String is empty.
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNullOrEmpty(String str) {
		return (str == null) || "".equals(str);
	}
	
	public static int returnIntegerValue(String msg) {
		int retVal = 0;
		try {
			retVal = Integer.parseInt(msg);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return retVal;
	}
}
