package com.ducont.core;

public class AppName {

	public String getAppName(String appId) {
		
		String appName = null;
		if (appId.equalsIgnoreCase("1")) {
			appName = "product Android";
		} else if (appId.equalsIgnoreCase("2")) {
			appName = "product iOS";
		} else if (appId.equalsIgnoreCase("6")) {
			appName = "ahlibank Android";
		} else if (appId.equalsIgnoreCase("7")) {
			appName = "ahlibank iOS";
		} else if (appId.equalsIgnoreCase("8")) {
			appName = "alhilal Android";
		} else if (appId.equalsIgnoreCase("9")) {
			appName = "alhilal iOS";
		}
		return appName;
	}
}
