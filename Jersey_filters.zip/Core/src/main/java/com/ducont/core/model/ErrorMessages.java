package com.ducont.core.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "ErrorMessages")
public class ErrorMessages implements Serializable {

	public ErrorMessages() {

	}

	private static final long serialVersionUID = -2438341079537708076L;
	@Id
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "ErrorId", unique = true, nullable = false)
	private String errorId;

	@Column(name = "ErrorCode")
	private String errorCode;

	@Column(name = "ErrorDescription")
	private String errorDescription;

	@Id
	@Column(name = "LangId")
	private String langId;

	@Column(name = "IsDeleted")
	private char IsDeleted;

	public String getErrorId() {
		return errorId;
	}

	public void setErrorId(String errorId) {
		this.errorId = errorId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getLangId() {
		return langId;
	}

	public void setLangId(String langId) {
		this.langId = langId;
	}

	public char getIsDeleted() {
		return IsDeleted;
	}

	public void setIsDeleted(char isDeleted) {
		IsDeleted = isDeleted;
	}
}
