package com.ducont.core.util.encryption;

import java.util.Properties;

import com.ducont.core.util.EWalletUtil;

public class CipherConstans {

	
	public static String getSecretKey() {
		
		Properties properties = EWalletUtil.getConfigurationProperties();
		return properties.getProperty("CipherSecretC.KEY");
	}
}
