package com.ducont.core.dao.api;

import com.ducont.core.model.HostLog;

public interface IHostLogDAO {

	public void createHostLogRecord(HostLog hostLog) throws Exception;
	
	public void updateHostLogRecord(HostLog hostLog) throws Exception;
	
}
