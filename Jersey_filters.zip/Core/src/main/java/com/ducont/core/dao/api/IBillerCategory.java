package com.ducont.core.dao.api;

import java.util.List;

import com.ducont.core.model.Biller;
import com.ducont.core.model.BillerCategory;

public interface IBillerCategory {

	public List<BillerCategory> getBillerCategories() throws Exception;
	
	public BillerCategory getBillerCategory(char categoryId) throws Exception;
	
	public Biller getBiller(long billerId) throws Exception;
}
