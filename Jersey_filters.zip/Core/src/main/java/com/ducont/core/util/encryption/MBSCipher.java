package com.ducont.core.util.encryption;


public interface MBSCipher {
    
   // public static final String MBS_SESSION_TOKEN = "ptoken";

    public abstract String decryptionData(String msg);
    
    public abstract String encryptionData(String msg);
    
    public abstract String encryptionData(String key, String msg);
    
    public abstract String decryptionData(String key, String msg);
    
    public abstract String decryptionRequestData(String msg);
    
    public abstract String getSessionkey();
    
   
}
