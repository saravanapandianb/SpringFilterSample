package com.ducont.core.dao.api;

import com.ducont.core.model.ErrorMessages;

public interface IErrorMessage {

	/**
	 * To read the error message from database.
	 * 
	 * @param errorCode
	 * @param langId
	 * @return
	 * @throws Exception
	 */
	public ErrorMessages getErrorMessage(String errorCode, String langId) throws Exception;

}
