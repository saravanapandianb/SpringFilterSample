package com.ducont.core.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.IBillerCategory;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.Biller;
import com.ducont.core.model.BillerCategory;
import com.ducont.core.util.HibernateUtil;

public class BillerCategoryDAO implements IBillerCategory {

	private static Logger LOGGER = LoggerFactory.getLogger(BillerCategoryDAO.class);

	@SuppressWarnings("unchecked")
	public List<BillerCategory> getBillerCategories() throws Exception {

		LOGGER.info("Fetch the Biller Categories begins...");

		Session session = null;
		Criteria criteria;
		List<BillerCategory> billerCategory = new ArrayList<>();

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			criteria = session.createCriteria(BillerCategory.class, "category")
					.add(Restrictions.eq("isDeleted", 'N'))
					.add(Restrictions.eq("status", 'A'))
					.createCriteria("category.billers", "biller", CriteriaSpecification.LEFT_JOIN,
							Restrictions.and(Restrictions.eq("biller.isDeleted", 'N'),
									Restrictions.eq("biller.status", 'A')));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			billerCategory = criteria.list();
			
			session.getTransaction().commit();
		} catch (Exception e) {

			LOGGER.error("Fetch the Biller Categories failed.", e);
			throw new AppException("READ_BILLER_CATEGORY_FAILED", e);
		}

		LOGGER.info("Fetch the Biller Categories ends...");
		return billerCategory;
	}

	public BillerCategory getBillerCategory(char categoryId) throws Exception {

		LOGGER.info("Fetch the details for category : " + categoryId + " Begins");
		Session session = null;
		Criteria criteria;
		BillerCategory billerCategory = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			criteria = session.createCriteria(BillerCategory.class);
			criteria.add(Restrictions.eq("billerCategoryId", categoryId));
			criteria.add(Restrictions.eq("isDeleted", 'N'));
			criteria.add(Restrictions.eq("status", 'A'));
			billerCategory = (BillerCategory) criteria.uniqueResult();

			session.getTransaction().commit();
		} catch (Exception e) {

			LOGGER.error("Fetch the details for category : " + categoryId + " failed.", e);
			throw new Exception("Fetch the details for category : " + categoryId + " failed.", e);
		}

		LOGGER.info("Fetch the details for category : " + categoryId + " ends");
		return billerCategory;
	}
	
	public Biller getBiller(long billerId) throws Exception {

		LOGGER.info("Fetch the details for biller : " + billerId + " Begins");
		Session session = null;
		Criteria criteria;
		Biller biller = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			criteria = session.createCriteria(Biller.class);
			criteria.add(Restrictions.eq("id", Long.valueOf(billerId)));
			criteria.add(Restrictions.eq("isDeleted", 'N'));
			criteria.add(Restrictions.eq("status", 'A'));
			biller = (Biller) criteria.uniqueResult();

			session.getTransaction().commit();
		} catch (Exception e) {

			LOGGER.error("Fetch the details for biller : " + billerId + " failed.", e);
			throw new Exception("Fetch the details for biller : " + billerId + " failed.", e);
		}

		LOGGER.info("Fetch the details for biller : " + billerId + " ends");
		return biller;
	}
}
