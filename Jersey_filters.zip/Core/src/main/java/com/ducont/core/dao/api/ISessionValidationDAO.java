package com.ducont.core.dao.api;

import com.ducont.core.model.CustomerToken;
import com.ducont.core.model.UserSession;

public interface ISessionValidationDAO {

	public CustomerToken getUniqueKey(String deviceId) throws Exception;

	public boolean updateCustomerToken(CustomerToken customerToken) throws Exception;

	public void saveUniqueKey(CustomerToken custtoken) throws Exception;

	public UserSession getSessionToken(String userId, String deviceId) throws Exception;

	public void updateSessionToken(UserSession usersession) throws Exception;

	public void saveSession(UserSession sessiontoken) throws Exception;
}
