package com.ducont.core.util.encryption;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.util.encoders.Base64;

/**
 * 
 * @author
 *
 */
public class SHAEncoder {
	public static SHAEncoder instance = null;
	public final static int ITERATION_COUNT = 5;

	public static synchronized SHAEncoder getInstance() {
		if (instance == null) {
			instance = new SHAEncoder();
			return instance;
		} else {
			return instance;
		}
	}

	public synchronized String encode(String pin) throws NoSuchAlgorithmException, IOException {
		String encodedPin = null;
		try {
			byte[] salt = pin.getBytes("iso-8859-1");
			MessageDigest digest = MessageDigest.getInstance(new SHA1Digest().getAlgorithmName());
			digest.reset();
			digest.update(salt, 0, salt.length);
			byte[] pwd = new byte[40];
			digest.digest(pwd, 0, pwd.length);
			encodedPin = byteToBase64(pwd);
		} catch (Exception e) {
		}
		return encodedPin;
	}

	private String byteToBase64(byte[] bt) {
		String returnString = new String(Base64.encode(bt));
		return returnString;
	}
}