package com.ducont.core.exception;

import java.util.ArrayList;
import java.util.List;

import com.ducont.core.Error;
import com.ducont.core.ErrorCode;

public class AppException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private List<Error> errors;
	private transient List<ErrorCode> errorCodes;

	public AppException() {
		super();
	}

	public AppException(String message) {
		super(message);
	}

	public AppException(Throwable cause) {
		super(cause);
	}

	public AppException(String message, Throwable cause) {
		super(message, cause);
	}

	public AppException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AppException(List<Error> errors) {
		this.errors = errors;
	}

	public AppException(Error error) {

		super(error.toString());
		errors = new ArrayList<Error>(1);
		add(error);
	}

	public AppException(Error error, Throwable cause) {

		super(error.toString(), cause);
		errors = new ArrayList<Error>(1);
		add(error);
	}

	public AppException(ErrorCode code) {
		this(new Error(code));
	}

	public AppException(ErrorCode code, String data) {
		this(new Error(code, data));
	}

	public AppException(ErrorCode code, long data) {
		this(new Error(code, data));
	}

	public AppException(ErrorCode code, Throwable cause) {

		super(code.toString(), cause);
		errors = new ArrayList<Error>(1);
		add(new Error(code, cause.getMessage()));
	}

	public List<Error> getErrors() {
		return errors;
	}

	private void add(Error err) {

		errors.add(err);
		if (errorCodes != null)
			errorCodes.add(err.getCode());
	}

	public List<ErrorCode> getErrCodes() {

		if (errorCodes != null)
			return errorCodes;

		errorCodes = new ArrayList<ErrorCode>(errors.size());
		for (Error err : errors) {
			errorCodes.add(err.getCode());
		}
		return errorCodes;
	}

	public boolean hasError(ErrorCode code) {
		return getErrCodes().contains(code);
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder(AppException.class.getName());
		if (errors != null) {
			for (Error err : errors) {
				sb.append("\n").append(err.toString());
			}
		}
		return sb.toString();
	}

	public static AppException getAppException(Throwable t) {

		AppException ae = null;

		Throwable cause = t;
		while (cause != null) {

			try {
				ae = (AppException) cause;
				break;
			} catch (ClassCastException cce) {
				cause = cause.getCause();
			}
		}

		return ae;
	}

	public static boolean isDBConnectionIssue(Throwable t) {

		return t.getMessage().contains("ORA-") || t.getMessage().contains("Closed Connection");
	}
}
