package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BillerCategory")
public class BillerCategoryLite implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@Column(name = "BillerCategoryId")
	private char billerCategoryId;
	
	@Column(name = "BillerCategoryName")
	private String billerCategoryName;

	@Column(name = "DateCreated")
	private Date dateCreated;

	@Column(name = "Status")
	private char status;

	@Column(name = "IsDeleted")
	private char isDeleted;

	public char getBillerCategoryId() {
		return billerCategoryId;
	}

	public void setBillerCategoryId(char billerCategoryId) {
		this.billerCategoryId = billerCategoryId;
	}

	public String getBillerCategoryName() {
		return billerCategoryName;
	}

	public void setBillerCategoryName(String billerCategoryName) {
		this.billerCategoryName = billerCategoryName;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public char getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(char isDeleted) {
		this.isDeleted = isDeleted;
	}
}
