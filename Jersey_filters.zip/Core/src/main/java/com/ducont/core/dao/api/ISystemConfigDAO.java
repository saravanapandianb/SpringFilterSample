package com.ducont.core.dao.api;

import com.ducont.core.model.ServiceMgmt;
import com.ducont.core.model.SystemInfo;

public interface ISystemConfigDAO {

	public SystemInfo getSystemInfo(String property) throws Exception;
	
	public ServiceMgmt getServiceByCode(int scode) throws Exception;
	
}
