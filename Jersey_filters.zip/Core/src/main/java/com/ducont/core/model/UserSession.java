package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "UserSession")
public class UserSession implements Serializable {
	
	private static final long serialVersionUID = -2438341079537708076L;
	@Id
	@Column(name = "UserID")
	private String userId;

	@Column(name = "AppID")
	private Integer appId;

	@Column(name = "ServiceId")
	private Integer serviceId;

	@Column(name = "DeviceId")
	private String deviceId;

	@Column(name = "SessionToken")
	private String sessionToken;

	@Column(name = "LastAccess")
	private Date lastAccess;

	@Column(name = "Status")
	private Integer loginStatus;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	public Date getLastAccess() {
		return lastAccess;
	}

	public void setLastAccess(Date lastAccess) {
		this.lastAccess = lastAccess;
	}

	public Integer getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(Integer loginStatus) {
		this.loginStatus = loginStatus;
	}

}
