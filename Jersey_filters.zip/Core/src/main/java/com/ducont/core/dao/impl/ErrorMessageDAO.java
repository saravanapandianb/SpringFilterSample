package com.ducont.core.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.IErrorMessage;
import com.ducont.core.model.ErrorMessages;
import com.ducont.core.util.ArabicConverter;
import com.ducont.core.util.HibernateUtil;

public class ErrorMessageDAO implements IErrorMessage {

	private static Logger LOGGER = LoggerFactory.getLogger(ErrorMessageDAO.class);
	
	@Override
	public ErrorMessages getErrorMessage(String errorCode, String langId) throws Exception {

		LOGGER.info("Fetch the error records begins for errorcode : " + errorCode);

		Session session = null;
		Criteria criteria;
		ErrorMessages errorMessage = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			
			criteria = session.createCriteria(ErrorMessages.class);
			criteria.add(Restrictions.eq("langId", langId));
			criteria.add(Restrictions.eq("errorCode", errorCode));
			errorMessage = (ErrorMessages) criteria.uniqueResult();
			
			session.getTransaction().commit();
		} catch (Exception e) {

			LOGGER.error("Fetch the error records failed for errorcode : " + errorCode, e);
			throw new Exception("Fetch the error records failed for errorcode : " + errorCode, e);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		LOGGER.info("Fetch the error records ends for errorcode : " + errorCode);
		
		if("AR".equalsIgnoreCase(langId)) {
			
			ArabicConverter converter = new ArabicConverter();
			String arabicmessage = converter.convertUTF8ToArabic("|*UTF8|" + errorMessage.getErrorDescription());
			errorMessage.setErrorDescription(arabicmessage);
		}
		return errorMessage;
	}
}
