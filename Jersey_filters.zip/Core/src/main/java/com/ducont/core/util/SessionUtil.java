package com.ducont.core.util;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.dao.impl.SessionValidationDAO;
import com.ducont.core.dao.impl.SystemConfigDAO;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.RequestHeader;
import com.ducont.core.model.SystemInfo;
import com.ducont.core.model.UserSession;

public class SessionUtil {

	public String errorMsg;

	final Logger logger = LoggerFactory.getLogger(SessionUtil.class);

	/**
	 * This method is responsible for validating session key for previous and
	 * current Request 1. Get session details from USER_SESSION Table 2. Extract
	 * Login status from table if login_status ==0 user logged out else if status==1
	 * user logged in 3. Get session token and last access time from USER_SESSION
	 * table 4. Calculate time difference(minutes) between current request last
	 * access time 5. Get configured Session time from DB 6. Compare
	 * prevSesKey==curSesKey && dbSessTime>=difference(minutes) between current
	 * request last access time return success value else return failure value
	 * 
	 */
	public boolean sessionTokenValidation(RequestHeader requestHeader, String mobileNumber) throws Exception {

		UserSession userSession = null;
		SessionValidationDAO sessionDAO = new SessionValidationDAO();
		SystemConfigDAO systemConfigDAO = new SystemConfigDAO();

		String oldSessionToken = null;
		String currSessionToken = null;
		SystemInfo systemInfo = null;

		try {

			if (UniqueKeyValidation.uniqueKeyValidation(requestHeader)) {
				/*
				 * Get the session for Logged in user
				 */
				userSession = sessionDAO.getSessionToken(mobileNumber, requestHeader.getDeviceId());
				/*
				 * get login status from UserSession Table if status is 0 =====> logged out 1
				 * =====> LoggedIn
				 */
				int loginStat = 0;
				if (userSession != null) {
					loginStat = userSession.getLoginStatus();
				}

				/*
				 * checking whether is logged in or not if logged in check session time
				 * difference b/n req
				 */
				if (loginStat == 1) {

					/*
					 * get Session id from table
					 */
					oldSessionToken = userSession.getSessionToken();
					System.out.println("old session----" + oldSessionToken);
					/*
					 * get Session sent with current Request
					 */
					currSessionToken = requestHeader.getSessionId();
					System.out.println("new session----" + currSessionToken);

					/*
					 * Get last access time for user from table
					 */
					Date lastAccessDateTime = userSession.getLastAccess();

					String curDateTime = DateUtil.getDateTime();

					Date curDate = DateUtil.convertStringToDate(curDateTime);

					/*
					 * Calculate the difference between current request and previous request
					 */
					int timeDiffMin = DateUtil.getDateDiff(curDate, lastAccessDateTime);

					systemInfo = systemConfigDAO.getSystemInfo("SESSION_TIME");
					String sesionTimeFromDB = systemInfo.getPropertyValue();

					long sessionTime = Integer.parseInt(sesionTimeFromDB);

					/*
					 * configured Session Time session time
					 */
					// long sessionTime = Integer.parseInt(sysinfo.get(7));

					/*
					 * if previous session key and current session key and configuredSessionTime
					 * greater than requested time in minutes then continue send session validation
					 * successful
					 */
					if (!(oldSessionToken.equalsIgnoreCase(currSessionToken) && sessionTime > timeDiffMin)) {

						errorMsg = "USER_SESSIONTIME_EXPIRED";
						logger.error("Class:SessionUtil, MethodName:sessionTokenValidation, Error : " + errorMsg);
						throw new AppException(errorMsg);
					}

				} else {

					errorMsg = "USER_NOT_LOGGEDIN";
					logger.error("Class:SessionUtil, MethodName:sessionTokenValidation, Error : " + errorMsg);
					throw new AppException(errorMsg);

				}
			} else {

				errorMsg = "MSG_REJECT_REQUEST";
				logger.error("Class:SessionUtil, MethodName:sessionTokenValidation, Error : " + errorMsg);
				throw new AppException(errorMsg);
			}
		} catch (AppException e) {

			throw e;
		} catch (Exception e) {

			errorMsg = "USER_SESSIONTIME_EXPIRED";
			logger.error("Class:SessionUtil, MethodName:sessionTokenValidation, Error : " + errorMsg);
			throw new AppException(errorMsg);
		}

		return true;

	}

	// This is for getting old session and updating new session
	public void updateSession(RequestHeader requestHeader, String mobileNumber) throws Exception {

		SessionValidationDAO sessionDAO = new SessionValidationDAO();

		try {
			UserSession userSession = null;

			userSession = sessionDAO.getSessionToken(mobileNumber, requestHeader.getDeviceId());

			/* Get new Session Token to send along with response */
			String sessionToken = EncryptionUtil.getSecureToken();
			requestHeader.setSessionId(sessionToken);

			if (userSession != null) {

				userSession.setSessionToken(sessionToken);
				userSession.setLastAccess(new Date());
				userSession.setLoginStatus(1);
				/* update session with new key for logged in user */

				sessionDAO.updateSessionToken(userSession);

			} else {

				UserSession session = new UserSession();
				session.setAppId(Integer.getInteger(requestHeader.getAppId()));
				session.setDeviceId(requestHeader.getDeviceId());
				session.setLastAccess(new Date());
				session.setLoginStatus(1);
				session.setServiceId(requestHeader.getServiceCode());
				session.setUserId(mobileNumber);
				session.setSessionToken(requestHeader.getSessionId());

				sessionDAO.saveSession(session);

			}
		} catch (Exception e) {
			
			errorMsg = "Upate user session failed.";
			logger.error("Class:SessionUtil, updateSession, Error : " + errorMsg);
			throw new Exception(errorMsg);
		}

	}
}
