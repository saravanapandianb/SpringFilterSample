package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "TransLog")
public class TransLog implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@Column(name = "TransLogId", unique = true, nullable = false)
	private int transLogId;

	@Column(name = "ServiceId")
	private int serviceId;

	@Column(name = "DrWalletId")
	private String debitWalletId;

	@Column(name = "CrWalletId")
	private String creditWalletId;

	@Column(name = "TransAmount")
	private double transAmount;

	@Column(name = "TransCurrency")
	private String transCurrency;

	@Column(name = "TransTime")
	private Date transTime;

	@Column(name = "Status")
	private char status;

	@Column(name = "ErrorCode")
	private String errorCode;

	@Column(name = "walletmobile")
	private String walletMobile;

	@Column(name = "walletcustomername")
	private String walletCustomerName;

	@Column(name = "walletbalance")
	private float walletBalance;

	@Column(name = "AppName")
	private String appName;

	@Column(name = "HostRefNo")
	private String hostRefNo;

	@Column(name = "flag")
	private char flag;

	@Column(name = "ServiceName")
	private String serviceName;
	
	@OneToMany
	@JoinColumn(name = "transReference", referencedColumnName = "transLogId", insertable = false, updatable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	private List<TransHistory> transHistories;
	
	@OneToOne
	@JoinColumn(name = "DrWalletId", referencedColumnName = "walletId", insertable = false, updatable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	private Wallet debitWallet;

	@OneToOne
	@JoinColumn(name = "CrWalletId", referencedColumnName = "walletId", insertable = false, updatable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	private Wallet creditWallet;
	
	public int getTransLogId() {
		return transLogId;
	}

	public void setTransLogId(int transLogId) {
		this.transLogId = transLogId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getDebitWalletId() {
		return debitWalletId;
	}

	public void setDebitWalletId(String debitWalletId) {
		this.debitWalletId = debitWalletId;
	}

	public String getCreditWalletId() {
		return creditWalletId;
	}

	public void setCreditWalletId(String creditWalletId) {
		this.creditWalletId = creditWalletId;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public String getTransCurrency() {
		return transCurrency;
	}

	public void setTransCurrency(String transCurrency) {
		this.transCurrency = transCurrency;
	}

	public Date getTransTime() {
		return transTime;
	}

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getWalletMobile() {
		return walletMobile;
	}

	public void setWalletMobile(String walletMobile) {
		this.walletMobile = walletMobile;
	}

	public String getWalletCustomerName() {
		return walletCustomerName;
	}

	public void setWalletCustomerName(String walletCustomerName) {
		this.walletCustomerName = walletCustomerName;
	}

	public float getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(float walletBalance) {
		this.walletBalance = walletBalance;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getHostRefNo() {
		return hostRefNo;
	}

	public void setHostRefNo(String hostRefNo) {
		this.hostRefNo = hostRefNo;
	}

	public char getFlag() {
		return flag;
	}

	public void setFlag(char flag) {
		this.flag = flag;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

}
