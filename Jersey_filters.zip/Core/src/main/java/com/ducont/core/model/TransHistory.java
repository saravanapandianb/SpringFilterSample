package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TransHistory")
public class TransHistory implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;
	@Id
	@Column(name = "TransId")
	private int transId;

	@Column(name = "BalanceAmount")
	private double balanceAmount;

	@Column(name = "Remarks", nullable = true)
	private String remarks;

	@Column(name = "ServiceCode")
	private int serviceCode;

	@Column(name = "Status")
	private char status;

	@Column(name = "TransAmount")
	private double transAmount;

	@Column(name = "TransCurrency")
	private String transCurrency;

	@Column(name = "TransDate")
	private Date transDate;

	@Column(name = "TransReference", nullable = true)
	private String transReference;

	@Column(name = "TransType")
	private char transType;

	@Column(name = "WalletID")
	private long walletID;

	@Column(name = "TransMobile")
	private String transMobile;

	@Column(name = "TransDescription", nullable = true)
	private String transDescription;

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(int serviceCode) {
		this.serviceCode = serviceCode;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public String getTransCurrency() {
		return transCurrency;
	}

	public void setTransCurrency(String transCurrency) {
		this.transCurrency = transCurrency;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public String getTransReference() {
		return transReference;
	}

	public void setTransReference(String transReference) {
		this.transReference = transReference;
	}

	public char getTransType() {
		return transType;
	}

	public void setTransType(char transType) {
		this.transType = transType;
	}

	public long getWalletID() {
		return walletID;
	}

	public void setWalletID(long walletID) {
		this.walletID = walletID;
	}

	public String getTransMobile() {
		return transMobile;
	}

	public void setTransMobile(String transMobile) {
		this.transMobile = transMobile;
	}

	public String getTransDescription() {
		return transDescription;
	}

	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}

}
