package com.ducont.core.dao.api;

import com.ducont.core.model.AuditLog;
import com.ducont.core.model.TransHistory;
import com.ducont.core.model.TransLog;

public interface ITransLogDAO {

	public void createTransLogRecord(TransLog transLog) throws Exception;
	
	public void createTransactionHistory(TransHistory transHistory) throws Exception;
	
	public void updateTransLogRecord(TransLog transLog) throws Exception;
	
	public void createAuditLog(AuditLog auditLog) throws Exception;
	
}
