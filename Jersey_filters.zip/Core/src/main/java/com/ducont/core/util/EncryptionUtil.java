package com.ducont.core.util;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.exception.AppException;
import com.ducont.core.util.encryption.CipherSecretC;
import com.ducont.core.util.encryption.MBSCipher;

public class EncryptionUtil {
	
	private static Logger LOGGER = LoggerFactory.getLogger(EncryptionUtil.class);

	/**
	 * To encrypt the plain text.
	 * 
	 * @param plainText
	 * @param key
	 * @return String
	 */
	public static String encrypt(String plainText, String key) {

		byte[] encryptedIVAndText = "".getBytes();
		
		try {

			byte[] clean = plainText.getBytes();

			// Generating IV.
			int ivSize = 16;
			int keySize = 16;
			
			byte[] iv = new byte[ivSize];
			SecureRandom random = new SecureRandom();
			random.nextBytes(iv);
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

			// Hashing key.
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			digest.update(key.getBytes("UTF-8"));
			byte[] keyBytes = new byte[keySize];
			System.arraycopy(digest.digest(), 0, keyBytes, 0, keyBytes.length);
			SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");

			// Encrypt.
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
			byte[] encrypted = cipher.doFinal(clean);

			// Combine IV and encrypted part.
			encryptedIVAndText = new byte[ivSize + encrypted.length];
			System.arraycopy(iv, 0, encryptedIVAndText, 0, ivSize);
			System.arraycopy(encrypted, 0, encryptedIVAndText, ivSize, encrypted.length);

		} catch (Exception e) {

			LOGGER.error("Encryption failed. " , e);
			throw new AppException("Encryption failed." , e);
		}
		return StringUtils.bytesToString(encryptedIVAndText);
	}

	/**
	 * To decrypt the encrypted text.
	 * 
	 * @param encryptedIvText
	 * @param key
	 * @return String
	 */
	public static String decrypt(String encryptedIvText, String key) {

		byte[] encryptedIvTextBytes = StringUtils.stringToBytes(encryptedIvText);
		String decryptedString = "";

		try {

			int ivSize = 16;
			int keySize = 16;

			// Extract IV.
			byte[] iv = new byte[ivSize];
			System.arraycopy(encryptedIvTextBytes, 0, iv, 0, iv.length);
			IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

			// Extract encrypted part.
			int encryptedSize = encryptedIvTextBytes.length - ivSize;
			byte[] encryptedBytes = new byte[encryptedSize];
			System.arraycopy(encryptedIvTextBytes, ivSize, encryptedBytes, 0, encryptedSize);

			// Hash key.
			byte[] keyBytes = new byte[keySize];
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(key.getBytes());
			System.arraycopy(md.digest(), 0, keyBytes, 0, keyBytes.length);
			SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");

			// Decrypt.
			Cipher cipherDecrypt = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipherDecrypt.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
			byte[] decrypted = cipherDecrypt.doFinal(encryptedBytes);
			decryptedString = new String(decrypted);

		} catch (Exception e) {

			LOGGER.error("Decryption failed.", e);
			throw new AppException("Decryption failed." , e);
		}

		return decryptedString;
	}


	public static void main(String[] args) throws Exception {

		String key = "Duc@nt"; // 128 bit key

		String encyptedText = encrypt("KPKTPQ", key);
		System.out.println(encyptedText);
		System.out.println(decrypt(encyptedText, key));
	}
	
	
	
	public static String decryptRequest(String request) {
		
		MBSCipher ciper = null;
		ciper = new CipherSecretC();	
		String decryptedRequest = null;
		decryptedRequest = ciper.decryptionRequestData(request);
		return decryptedRequest;
	}

	public static String encryptRequest(String response, String secureKey) {
		
		CipherSecretC ciper = new CipherSecretC();
		return ciper.encryptionData(secureKey, response);
	}
	
	
	public static String getSecureToken() {

		SecureRandom ranGen = new SecureRandom();
		byte[] aesKey = new byte[16]; // 16 bytes = 128 bits
		ranGen.nextBytes(aesKey);
		String sessionKey = hexEncode(aesKey);

		return sessionKey;
	}

	private static String hexEncode(byte[] aInput) {
		
		StringBuilder result = new StringBuilder();
		char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		for (int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append(digits[(b & 0xf0) >> 4]);
			result.append(digits[b & 0x0f]);
		}
		return result.toString();
	}
}