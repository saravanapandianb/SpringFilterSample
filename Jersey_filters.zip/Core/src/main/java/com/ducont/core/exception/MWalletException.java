/**
*   <p>Created on Sep 01, 2012
*  Copyright (C) 2000-12 Ducont FZ LLC. All rights reserved.
*  Warning : This computer program is protected by copyright laws and
*  international treaties. Unauthorised reproduction, or usage, of this
*  program, or any portion of it, in any form, by the customer or their
*  partners will result in severe civil and criminal penalties and will be
*  prosecuted to the maximum extent possible under the law.
*
*   @author : Jayachandra A
*   @version 1.2</p>
*   @modified by:
*/

package com.ducont.core.exception;

import java.io.Serializable;

/**
 * Class Name: MWalletException This class used for catching the exception
 * occuring during the construction of MWalletPool
 */
public class MWalletException extends RuntimeException implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -304449238334685355L;

	/**
	 * Consructor : MWalletException Initialises the class
	 */
	public MWalletException(String s) {
		super(s);
	}

	/**
	 * Function : toString Convert error message to string.
	 */
	public String toString() {
		return super.toString();
	}
}