package com.ducont.core.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.ISystemConfigDAO;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.ServiceMgmt;
import com.ducont.core.model.SystemInfo;
import com.ducont.core.util.HibernateUtil;

public class SystemConfigDAO implements ISystemConfigDAO {

	private static Logger LOGGER = LoggerFactory.getLogger(SystemConfigDAO.class);

	@Override
	public SystemInfo getSystemInfo(String property) throws Exception {

		LOGGER.info("Fetch the system config details for : " + property + " begins");
		Session session = null;
		Transaction transaction = null;
		Criteria criteria = null;
		SystemInfo systeminfo = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();

			criteria = session.createCriteria(SystemInfo.class);
			criteria.add(Restrictions.eq("property", property).ignoreCase());
			systeminfo = (SystemInfo) criteria.uniqueResult();

			transaction.commit();
		} catch (Exception e) {

			if (transaction != null) {
				transaction.rollback();
			}
			LOGGER.error("Fetch the system config details for : " + property + " failed.", e);
			throw new Exception("Fetch the system config details for : " + property + " failed.", e);
		} finally {

			session.close();
		}

		LOGGER.info("Fetch the system config details for : " + property + " ends");
		return systeminfo;
	}
	
	public ServiceMgmt getServiceByCode(int scode) throws Exception {
		
		LOGGER.info("Fetch the service details for " + scode + " begins.");
		Session session = null;
		Criteria criteria;
		ServiceMgmt serviceMgmt = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			criteria = session.createCriteria(ServiceMgmt.class);
			criteria.add(Restrictions.eq("serviceId", scode));
			criteria.setMaxResults(1);
			serviceMgmt = (ServiceMgmt) criteria.uniqueResult();

			session.getTransaction().commit();
			
			if (serviceMgmt != null) {

				if (serviceMgmt.getIsDeleted() != 'N')
					throw new AppException("SERVICE_ISDELETED");
				else if (serviceMgmt.getServiceStatus() != 'A')
					throw new AppException("SERVICE_INACTIVE");
			} else {
				throw new AppException("SERVICE_NOT_AVAILABLE");
			}
			
		} catch (AppException e) {

			LOGGER.error("Fetch the service details for " + scode + " failed.", e);
			throw e;
		} catch (Exception e) {

			LOGGER.error("Fetch the service details for " + scode + " failed.", e);
			throw new Exception("Fetch the service details for " + scode + " failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		LOGGER.info("Fetch the service details for " + scode + " ends.");
		return serviceMgmt;
	}
}
