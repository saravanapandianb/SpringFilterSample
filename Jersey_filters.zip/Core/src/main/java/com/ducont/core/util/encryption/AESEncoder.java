package com.ducont.core.util.encryption;

import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.engines.AESLightEngine;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PKCS7Padding;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.encoders.Base64;

public class AESEncoder {

    //  8-byte Salt
    private static byte[] salt = {
        (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32,
        (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03
    };

    //  Iteration count
    private static int iterationCount = 19;
    private PaddedBufferedBlockCipher cipher;
    private KeyParameter keyParam;

    public AESEncoder(char[] pass) {
        try {
          init(pass);
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    private void init(char[] pass) throws Exception {
        PBEParametersGenerator generator = new PKCS5S2ParametersGenerator();

        generator.init(PBEParametersGenerator.PKCS5PasswordToBytes(pass), salt, iterationCount);
        ParametersWithIV params = (ParametersWithIV) generator.generateDerivedParameters(128, 128);

        keyParam = (KeyParameter) params.getParameters();
        cipher = new PaddedBufferedBlockCipher(new CBCBlockCipher(new AESLightEngine()), new PKCS7Padding());
    }

    public String encrypt(String plainText) throws Exception {
        cipher.init(true, keyParam);
        byte[] plainTextBytes = plainText.getBytes("UTF-8");
        byte[] cipherTextBytes = new byte[cipher.getOutputSize(plainTextBytes.length)];
        int outputLen = cipher.processBytes(plainTextBytes, 0, plainTextBytes.length, cipherTextBytes, 0);

        cipher.doFinal(cipherTextBytes, outputLen);
        return new String(Base64.encode(cipherTextBytes));
    }

    public String decrypt(String cipherTextB64) throws Exception {
    	System.out.println("AESEncoder-----decrypt----66------");
        cipher.init(false, keyParam);
        byte[] cipherTextBytes = Base64.decode(cipherTextB64);
        byte[] plainTextBytes = new byte[cipher.getOutputSize(cipherTextBytes.length)];
        int outputLen = cipher.processBytes(cipherTextBytes, 0, cipherTextBytes.length, plainTextBytes, 0);
        cipher.doFinal(plainTextBytes, outputLen);
       // System.out.println("----------"+new String(plainTextBytes, "UTF-8")+"---66----");
        return new String(plainTextBytes, "UTF-8");
    }
}
