package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Wallet")
public class Wallet implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@GeneratedValue
	@Column(name = "WalletID")
	private long walletId;

	@Column(name = "MobileNO")
	private String mobileNumber;

	@Column(name = "BalanceAmount")
	private double balanceAmount;

	@Column(name = "Currency")
	private String currency;

	@Column(name = "CurrentTransDate")
	private Date currentTransDate;

	@Column(name = "DailyLimit")
	private float dailyLimit;

	@Column(name = "Deleted")
	private char deleted;

	@Column(name = "MinBalance")
	private float minimumBalance;

	@Column(name = "Status")
	private char status;

	@Column(name = "TransLimit")
	private float transLimit;

	@Column(name = "WalletName")
	private String name;

	@Column(name = "WalletType")
	private char type;

	@Column(name = "VELOCITY")
	private int velocity;

	@Column(name = "WalletCategory")
	private char category;

	@Column(name = "DateCreated")
	private Date createdDate;

	public long getWalletId() {
		return walletId;
	}

	public void setWalletId(long walletId) {
		this.walletId = walletId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getCurrentTransDate() {
		return currentTransDate;
	}

	public void setCurrentTransDate(Date currentTransDate) {
		this.currentTransDate = currentTransDate;
	}

	public float getDailyLimit() {
		return dailyLimit;
	}

	public void setDailyLimit(float dailyLimit) {
		this.dailyLimit = dailyLimit;
	}

	public char getDeleted() {
		return deleted;
	}

	public void setDeleted(char deleted) {
		this.deleted = deleted;
	}

	public float getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(float minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public float getTransLimit() {
		return transLimit;
	}

	public void setTransLimit(float transLimit) {
		this.transLimit = transLimit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getType() {
		return type;
	}

	public void setType(char type) {
		this.type = type;
	}

	public int getVelocity() {
		return velocity;
	}

	public void setVelocity(int velocity) {
		this.velocity = velocity;
	}

	public char getCategory() {
		return category;
	}

	public void setCategory(char category) {
		this.category = category;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
