package com.ducont.core;

public class SystemParameters {

	public static String POOL_ACCOUNT_ISLAMIC = "POOL_ACCOUNT_ISLAMIC";

	public static String CBO_POOL_ACC_ISLAMIC = "CBO_POOL_ACC_ISLAMIC";
}
