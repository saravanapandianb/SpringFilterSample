package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CustomerToken")
public class CustomerToken implements Serializable {
	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@Column(name = "CustTokenId")
	private int custTokenId;

	@Column(name = "DeviceId")
	private String deviceId;

	@Column(name = "UniqueKey")
	private String uniqueKey;

	@Column(name = "UpdateTime")
	private Date updateTime;

	public int getCustTokenId() {
		return custTokenId;
	}

	public void setCustTokenId(int custTokenId) {
		this.custTokenId = custTokenId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
