package com.ducont.core.util.encryption;

import com.ducont.core.Constants;

public class CipherSecret implements MBSCipher {

	public String KEY = CipherConstans.getSecretKey();

	public String encryptionData(String msg) {

		String encrptMsg = "";
		try {
			AESEncoder aesEncoder = new AESEncoder(KEY.toCharArray());
			encrptMsg = aesEncoder.encrypt(msg);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return encrptMsg;
	}

	/**
	 *
	 */
	public String encryptionData(String key, String msg) {
		String encrptMsg = "";
		try {
			AESEncoder aesEncoder = new AESEncoder(key.toCharArray());
			encrptMsg = aesEncoder.encrypt(msg);
			encrptMsg = encryptionData(key) + "&" + encrptMsg;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encrptMsg;
	}

	public String encryption(String key, String msg) {
		String encrptMsg = "";
		try {
			// encyKey = SHAEncoder.getInstance().encode(KEY);
			AESEncoder aesEncoder = new AESEncoder(key.toCharArray());
			encrptMsg = aesEncoder.encrypt(msg);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return encrptMsg;
	}

	/**
	 *
	 * @param msg
	 * @return
	 * @throws NumberFormatException
	 */
	public String decryptionData(String msg) {
		
		String decrptMsg = "";
		try {

			System.out.println("BFR Decoding:   " + msg);
			AESEncoder aesEncoder = new AESEncoder(KEY.toCharArray());
			decrptMsg = aesEncoder.decrypt(msg);
			decrptMsg = decrptMsg.replace((char) 0, (char) 32);
			decrptMsg = decrptMsg.trim();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return decrptMsg;
	}

	private String[] parseKeys(String response) {

		String key[] = response.split("&");
		String token = key[0];

		key[0] = decryptionData(token);

		return key;
	}

	public String decryptionData(String key, String msg) {
		
		String decrptMsg = "";
		try {
			AESEncoder aesEncoder = new AESEncoder(key.toCharArray());
			decrptMsg = aesEncoder.decrypt(msg);
			decrptMsg = decrptMsg.replace((char) 0, (char) 32);
			decrptMsg = decrptMsg.trim();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decrptMsg;
	}

	public String decryptionRequestData(String data) {

		String requestKeys[] = parseKeys(data);
		data = decryptionData(requestKeys[0], requestKeys[1]);
		data = data + "&" + Constants.MBS_SESSION_TOKEN + "=" + requestKeys[0];
		return data;
	}

	@Override
	public String getSessionkey() {
		throw new UnsupportedOperationException("Not supported yet.");
	}
}
