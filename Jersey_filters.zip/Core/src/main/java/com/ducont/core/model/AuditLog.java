package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AuditLog")

public class AuditLog implements Serializable {
	private static final long serialVersionUID = 8349157963753985627L;

	@Id
	@Column(name = "AuditId", unique = true, nullable = false)
	private int auditId;

	@Column(name = "AppId")
	private int appId;

	@Column(name = "ServiceId")
	private int serviceId;

	@Column(name = "Sequence")
	private int sequence;

	@Column(name = "MobileNo")
	private String mobileNo;

	@Column(name = "TransInTime")
	private Date transInTime;

	@Column(name = "TransOutTime")
	private Date transOutTime;

	@Column(name = "TransDesc")
	private String transDesc;

	@Column(name = "Status")
	private int status;

	@Column(name = "SystemIP")
	private String systemIP;

	@Column(name = "Request")
	private String request;

	@Column(name = "Response")
	private String response;

	@Column(name = "DeviceId")
	private String deviceId;

	@Column(name = "Model")
	private String model;

	@Column(name = "OSVersion")
	private String osVersion;

	@Column(name = "AppVersion")
	private String appVersion;

	public int getAuditId() {
		return auditId;
	}

	public void setAuditId(int auditId) {
		this.auditId = auditId;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Date getTransInTime() {
		return transInTime;
	}

	public void setTransInTime(Date transInTime) {
		this.transInTime = transInTime;
	}

	public Date getTransOutTime() {
		return transOutTime;
	}

	public void setTransOutTime(Date transOutTime) {
		this.transOutTime = transOutTime;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getSystemIP() {
		return systemIP;
	}

	public void setSystemIP(String systemIP) {
		this.systemIP = systemIP;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
}
