package com.ducont.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Error {

	private ErrorCode code;
	private List<String> datas;

	public Error() {
	}

	public Error(ErrorCode code, List<String> data) {

		this.code = code;
		this.datas = data;
	}

	public Error(ErrorCode code, String data) {

		this.code = code;

		datas = new ArrayList<String>(1);
		datas.add(data);
	}

	public Error(ErrorCode code, long data) {
		this(code, String.valueOf(data));
	}

	public Error(ErrorCode code) {
		this.code = code;
	}

	public Error(String data) {
		this(ErrorCode.UNKNOWN, data);
	}

	public Error(ErrorCode code, String[] errData) {
		this(code, Arrays.asList(errData));
	}

	public ErrorCode getCode() {
		return code;
	}

	public List<String> getDatas() {
		return datas;
	}

	public void setCode(ErrorCode code) {
		this.code = code;
	}

	public void setDatas(List<String> datas) {
		this.datas = datas;
	}

	@Override
	public String toString() {
		return (datas == null) ? String.valueOf(code) : code + ";" + datas;
	}
}
