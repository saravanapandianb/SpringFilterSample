package com.ducont.core.dao.api;

import java.util.List;

import com.ducont.core.model.PaymentFrequency;

public interface IPaymentFrequency {

	public List<PaymentFrequency> getPaymentFrequency() throws Exception;
}
