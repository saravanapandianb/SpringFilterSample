package com.ducont.core.util.encryption;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.digest.DigestUtils;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.engines.AESFastEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;

import com.ducont.core.Constants;
import com.sun.jersey.core.util.Base64;

public class CipherSecretC implements MBSCipher {
	
	public String KEY = CipherConstans.getSecretKey();
	
	//public String KEY = "DUCONT1234";

	/*
	 * public String KEY11 = "DUCONT1234"; // public String KEY = "";
	 */ private String sessionkey = null;

	/**
	 * 
	 */
	public String encryptionData(String url) {
		String retString = "";
		try {
			byte[] retArr = encrypt(url.getBytes(StandardCharsets.UTF_8	));
			retString = new String(Base64.encode(retArr));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retString;
	}

	/**
	 *
	 */
	public String decryptionData(String url) {
		String retString = "";

		try {
			byte[] retArr = decrypt(Base64.decode(url));

			return new String(retArr);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return retString;
	}

	/**
	 *
	 * @param plainText
	 * @return
	 * @throws Exceptione
	 */
	public byte[] encrypt(byte[] plainText) throws Exception {
		return transform(true, plainText);
	}

	/**
	 *
	 * @param cipherText
	 * @return
	 * @throws Exception
	 */
	public byte[] decrypt(byte[] cipherText) throws Exception {
		return transform(false, cipherText);
	}

	/**
	 * 
	 * @param encrypt
	 * @param inputBytes
	 * @return
	 * @throws Exception
	 */
	private byte[] transform(boolean encrypt, byte[] inputBytes) throws Exception {

		byte[] key = DigestUtils.md5(KEY.getBytes("UTF-8"));
		BufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new CBCBlockCipher(new AESFastEngine()));
		cipher.init(encrypt, new KeyParameter(key));

		ByteArrayInputStream input = new ByteArrayInputStream(inputBytes);
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		int inputLen;
		int outputLen;
		byte[] inputBuffer = new byte[1024];
		byte[] outputBuffer = new byte[cipher.getOutputSize(inputBuffer.length)];
		while ((inputLen = input.read(inputBuffer)) > -1) {
			outputLen = cipher.processBytes(inputBuffer, 0, inputLen, outputBuffer, 0);
			if (outputLen > 0) {
				output.write(outputBuffer, 0, outputLen);
			}
		}

		outputLen = cipher.doFinal(outputBuffer, 0);
		if (outputLen > 0) {
			output.write(outputBuffer, 0, outputLen);
		}

		return output.toByteArray();
	}

	/**
	 *
	 */
	public String encryptionData(String key, String msg) {
		String response = encryptionData(key);
		KEY = key;
		response = response + "&" + encryptionData(msg);
		return response;
	}

	public String decryptionData(String key, String msg) {
		KEY = key;

		return decryptionData(msg);
	}

	private String[] parseKeys(String response) {
		String key[] = response.split("&");
		String token = key[0];

		key[0] = decryptionData(token);

		return key;
	}

	public String getSessionkey() {
		return sessionkey;
	}

	public void setSessionkey(String sessionkey) {
		this.sessionkey = sessionkey;
	}

	public String decryptionRequestData(String data) {
		String requestKeys[] = parseKeys(data);
		sessionkey = requestKeys[0];

		data = decryptionData(requestKeys[0], requestKeys[1]);
		
		data = data + "&" + Constants.MBS_SESSION_TOKEN + "=" + requestKeys[0];

		return data;
	}
}
