package com.ducont.core.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.ITransLogDAO;
import com.ducont.core.model.AuditLog;
import com.ducont.core.model.TransHistory;
import com.ducont.core.model.TransLog;
import com.ducont.core.util.HibernateUtil;

public class TransLogDAO implements ITransLogDAO {

	@Override
	public void createTransLogRecord(TransLog transLog) throws Exception {

		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			Criteria criteria = session.createCriteria(TransLog.class).setProjection(Projections.max("transLogId"));
			Integer max = (Integer) criteria.uniqueResult();
			if (max != null) {
				transLog.setTransLogId(max + 1);
			} else {
				transLog.setTransLogId(1);
			}
			session.saveOrUpdate(transLog);
			session.getTransaction().commit();
		} catch (Exception e) {

			throw new Exception("Adding transaction log failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void updateTransLogRecord(TransLog transLog) throws Exception {

		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			session.update(transLog);
			session.getTransaction().commit();
			
		} catch (Exception e) {

			throw new Exception("Updating transaction log failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public void createTransactionHistory(TransHistory transHistory) throws Exception {
		
		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			Criteria criteria = session.createCriteria(TransHistory.class).setProjection(Projections.max("transId"));
			Integer max = (Integer) criteria.uniqueResult();
			if (max != null) {
				transHistory.setTransId(max + 1);
			} else {
				transHistory.setTransId(1);
			}
			session.saveOrUpdate(transHistory);
			session.getTransaction().commit();
		} catch (Exception e) {

			throw new Exception("Adding transaction history failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@Override
	public void createAuditLog(AuditLog auditLog) throws Exception {

		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			Criteria criteria = session.createCriteria(AuditLog.class).setProjection(Projections.max("auditId"));
			Integer max = (Integer) criteria.uniqueResult();
			if (max != null) {
				auditLog.setAuditId(max + 1);
			} else {
				auditLog.setAuditId(1);
			}
			session.save(auditLog);
			session.getTransaction().commit();
		} catch (Exception e) {

			throw new Exception("Adding transaction log failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
