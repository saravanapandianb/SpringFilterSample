package com.ducont.core.util;

public class ArabicConverter {

	public String convertUTF8ToArabic(String MessageToConvert) {

		ArabicConverter ar = null;
		ar = new ArabicConverter();
		return ar.convertFromUCS2(ar.convertUtf8Ucs2(MessageToConvert));
	}

	public String convertArabicToUTF8(String message) {

		StringBuffer arabicString = null;

		try {
			arabicString = new StringBuffer();
			for (int i = 0; i < message.length(); i++) {
				if ((int) message.charAt(i) > 127) {
					arabicString.append("&#");
					arabicString.append(padder((int) message.charAt(i)));
					arabicString.append(";");
				} else {
					arabicString.append(message.charAt(i));
				}
			}
			return arabicString.toString();
		} catch (Exception exception) {
			return message;
		}
	}

	private String padder(int value) {

		String returnString = Integer.toString(value);
		int len = returnString.length();
		try {
			switch (len) {
			case 0:
				returnString = "0000" + returnString;
				break;
			case 1:
				returnString = "000" + returnString;
				break;
			case 2:
				returnString = "00" + returnString;
				break;
			case 3:
				returnString = "0" + returnString;
				break;
			}
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return returnString;
	}

	private String convertUtf8Ucs2(String body) {

		boolean insertSeperator = false;
		if (body != null && body.length() > 7 && (body.substring(0, 7)).equalsIgnoreCase("|*UTF8|")) {
			if (insertSeperator == true) {
				body = body + ";";
				insertSeperator = false;
			}
			body = body.substring(7, body.length());
			String cstr1 = body;
			char[] b = cstr1.toCharArray();
			String cstr = "";
			String bodystr = "";
			for (int countb = 0; countb < b.length; countb++) {
				if (b[countb] == '&' && b[countb + 1] == '#') {
					countb++;
					for (int counter = 0; counter < 5; counter++) {
						char c = b[++countb];
						if (c == ';') {
							bodystr = bodystr + padder(cstr, "0", 4, 'L');
							cstr = "";
							break;
						} else {
							cstr = cstr + c;
						}
					}
				} else {
					cstr = (int) b[countb] + "";
					bodystr = bodystr + padder(cstr, "0", 4, 'L');
					cstr = "";
				}
			}
			bodystr = convertToUCS2(bodystr);
			return bodystr;
		}
		return body;
	}

	private String convertFromUCS2(String dataToConvert) {

		String ucs2 = "";
		try {
			char[] b = dataToConvert.toCharArray();
			int i = 0;
			String str = "";
			for (int count = 0; count < b.length; count++) {
				str = str + b[count] + b[++count] + b[++count] + b[++count];
				i = Integer.valueOf(str, 16).intValue();
				ucs2 = ucs2 + (char) i;
				str = "";
			}
			return ucs2;
		} catch (Exception e) {
			ucs2 = "";
		}
		return ucs2;
	}

	private String convertToUCS2(String dataToConvert) {

		String ucs2 = "";
		try {
			char[] b = dataToConvert.toCharArray();
			int i = 0;
			String str = "";
			for (int count = 0; count < b.length; count++) {
				str = str + b[count] + b[++count] + b[++count] + b[++count];
				i = Integer.parseInt(str);
				ucs2 = ucs2 + padder(Integer.toString(i, 16), "0", 4, 'L');
				str = "";
			}
			return ucs2;
		} catch (Exception e) {
			ucs2 = "";
		}
		return ucs2;
	}

	private String padder(String data, String padWith, int length, char padAt) {

		if (data != null && data.length() < length) {
			if (data.length() == 1) {
				if (padAt == 'L') {
					data = padWith + data;
				} else if (padAt == 'R') {
					data = data + padWith;
				}
			}
			for (int i = 0; i <= length - data.length(); i++) {
				if (padAt == 'L') {
					data = padWith + data;
				} else if (padAt == 'R') {
					data = data + padWith;
				}
			}
		}
		return data;
	}
}
