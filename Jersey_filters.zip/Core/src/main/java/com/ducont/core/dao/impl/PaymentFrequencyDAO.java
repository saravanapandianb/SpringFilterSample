package com.ducont.core.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.IPaymentFrequency;
import com.ducont.core.exception.AppException;
import com.ducont.core.model.PaymentFrequency;
import com.ducont.core.util.HibernateUtil;

public class PaymentFrequencyDAO implements IPaymentFrequency {

	private static Logger LOGGER = LoggerFactory.getLogger(PaymentFrequencyDAO.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<PaymentFrequency> getPaymentFrequency() throws Exception {

		LOGGER.info("Fetch the payment frequency begins...");

		Session session = null;
		Criteria criteria;
		List<PaymentFrequency> paymentFrequency = new ArrayList<>();

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			criteria = session.createCriteria(PaymentFrequency.class);
			criteria.add(Restrictions.eq("isDeleted", 'N'));
			criteria.add(Restrictions.eq("status", 'A'));
			paymentFrequency = criteria.list();

			session.getTransaction().commit();
		} catch (Exception e) {

			LOGGER.error("Fetch the payment frequency failed.", e);
			throw new AppException("READ_PAYMENT_FREQUENCY_FAILED", e);
		}

		LOGGER.info("Fetch the payment frequency ends...");
		return paymentFrequency;
	}
}
