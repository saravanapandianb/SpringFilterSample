package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PaymentFrequency")
public class PaymentFrequency implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@GeneratedValue
	@Column(name = "PaymentFrequencyId")
	private long paymentFrequencyId;

	@Column(name = "Name")
	private String name;

	@Column(name = "Status")
	private char status;

	@Column(name = "IsDeleted")
	private char isDeleted;

	@Column(name = "DateCreated")
	private Date dateCreated;

	public long getPaymentFrequencyId() {
		return paymentFrequencyId;
	}

	public void setPaymentFrequencyId(long paymentFrequencyId) {
		this.paymentFrequencyId = paymentFrequencyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public char getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(char isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

}
