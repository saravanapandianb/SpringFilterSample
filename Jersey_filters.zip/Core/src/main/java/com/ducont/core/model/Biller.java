package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BillerM")
public class Biller implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@Column(name = "BillerId")
	private long id;

	@Column(name = "BillerName")
	private String billerName;

	@Column(name = "CategoryId")
	private char categoryId;

	@Column(name = "MinAmount")
	private float minAmount;

	@Column(name = "MaxAmount")
	private float maxAmount;

	@Column(name = "DateCreated")
	private Date dateCreated;

	@Column(name = "Status")
	private char status;

	@Column(name = "IsDeleted")
	private char isDeleted;

	@Column(name = "CreatedBy")
	private String createdBy;

	@Column(name = "ModifiedBy")
	private String modifiedBy;

	@Column(name = "ModifiedTime")
	private Date modifiedTime;
	
	@ManyToOne
    @JoinColumn(name = "CategoryId", updatable = false, insertable = false)
	protected BillerCategoryLite category;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBillerName() {
		return billerName;
	}

	public void setBillerName(String billerName) {
		this.billerName = billerName;
	}

	public char getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(char categoryId) {
		this.categoryId = categoryId;
	}

	public float getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(float minAmount) {
		this.minAmount = minAmount;
	}

	public float getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(float maxAmount) {
		this.maxAmount = maxAmount;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public char getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(char isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public BillerCategoryLite getCategory() {
		return category;
	}

	public void setCategory(BillerCategoryLite category) {
		this.category = category;
	}
	
}
