package com.ducont.core.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "HostLog")
public class HostLog implements Serializable {

	private static final long serialVersionUID = -2438341079537708076L;

	@Id
	@Column(name = "HostLogId", unique = true, nullable = false)
	private int hostLogId;

	@Column(name = "TransLogId")
	private int transLogId;

	@Column(name = "ServiceId")
	private int serviceId;

	@Column(name = "MobileNo")
	private String mobileNo;

	@Column(name = "AccountNo")
	private String accountNo;

	@Column(name = "TransAmount")
	private float transAmount;

	@Column(name = "Currency")
	private String currency;

	@Column(name = "HostTransAmount")
	private float hostTransAmount;

	@Column(name = "HostRequest")
	private String hostRequest;

	@Column(name = "HostResponse")
	private String hostResponse;

	@Column(name = "HostRefNo")
	private String hostRefNo;

	@Column(name = "HostTimeIn")
	private Date hostTimeIn;

	@Column(name = "HostTimeOut")
	private Date hostTimeOut;

	@Column(name = "TransType")
	private char transType;

	@Column(name = "HostTransType")
	private char hostTransType;

	@Column(name = "HostType")
	private String hostType;

	@Column(name = "BankType")
	private char bankType;

	@Column(name = "HostBankType")
	private char hostBankType;

	@Column(name = "SettlementDate")
	private Date settlementDate;

	@Column(name = "Reason")
	private String reason;

	@Column(name = "ErrorDesc")
	private String errorDesc;

	@Column(name = "HostStatus")
	private char hostStatus;

	@Column(name = "Status")
	private char status;

	@Column(name = "UpdatedTime")
	private Date updatedTime;

	@Column(name = "ReconStatus")
	private char reconStatus;

	@Column(name = "OnUs")
	private String onUs;

	public int getHostLogId() {
		return hostLogId;
	}

	public void setHostLogId(int hostLogId) {
		this.hostLogId = hostLogId;
	}

	public int getTransLogId() {
		return transLogId;
	}

	public void setTransLogId(int transLogId) {
		this.transLogId = transLogId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public float getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(float transAmount) {
		this.transAmount = transAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public float getHostTransAmount() {
		return hostTransAmount;
	}

	public void setHostTransAmount(float hostTransAmount) {
		this.hostTransAmount = hostTransAmount;
	}

	public String getHostRequest() {
		return hostRequest;
	}

	public void setHostRequest(String hostRequest) {
		this.hostRequest = hostRequest;
	}

	public String getHostResponse() {
		return hostResponse;
	}

	public void setHostResponse(String hostResponse) {
		this.hostResponse = hostResponse;
	}

	public String getHostRefNo() {
		return hostRefNo;
	}

	public void setHostRefNo(String hostRefNo) {
		this.hostRefNo = hostRefNo;
	}

	public Date getHostTimeIn() {
		return hostTimeIn;
	}

	public void setHostTimeIn(Date hostTimeIn) {
		this.hostTimeIn = hostTimeIn;
	}

	public Date getHostTimeOut() {
		return hostTimeOut;
	}

	public void setHostTimeOut(Date hostTimeOut) {
		this.hostTimeOut = hostTimeOut;
	}

	public char getTransType() {
		return transType;
	}

	public void setTransType(char transType) {
		this.transType = transType;
	}

	public char getHostTransType() {
		return hostTransType;
	}

	public void setHostTransType(char hostTransType) {
		this.hostTransType = hostTransType;
	}

	public String getHostType() {
		return hostType;
	}

	public void setHostType(String hostType) {
		this.hostType = hostType;
	}

	public char getBankType() {
		return bankType;
	}

	public void setBankType(char bankType) {
		this.bankType = bankType;
	}

	public char getHostBankType() {
		return hostBankType;
	}

	public void setHostBankType(char hostBankType) {
		this.hostBankType = hostBankType;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public char getHostStatus() {
		return hostStatus;
	}

	public void setHostStatus(char hostStatus) {
		this.hostStatus = hostStatus;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public char getReconStatus() {
		return reconStatus;
	}

	public void setReconStatus(char reconStatus) {
		this.reconStatus = reconStatus;
	}

	public String getOnUs() {
		return onUs;
	}

	public void setOnUs(String onUs) {
		this.onUs = onUs;
	}

}
