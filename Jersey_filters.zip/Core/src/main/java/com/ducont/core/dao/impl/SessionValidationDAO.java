package com.ducont.core.dao.impl;

import java.util.Date;

import javax.persistence.PersistenceException;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.ISessionValidationDAO;
import com.ducont.core.model.CustomerToken;
import com.ducont.core.model.UserSession;
import com.ducont.core.util.HibernateUtil;

public class SessionValidationDAO implements ISessionValidationDAO {

	public CustomerToken getUniqueKey(String deviceId) throws Exception {

		Session session = null;
		Transaction transaction = null;
		Criteria criteria = null;
		CustomerToken customerToken = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			transaction = session.beginTransaction();

			criteria = session.createCriteria(CustomerToken.class);
			criteria.add(Restrictions.eq("deviceId", deviceId));
			customerToken = (CustomerToken) criteria.uniqueResult();

			transaction.commit();
		} catch (Exception e) {

			if (transaction != null) {
				transaction.rollback();
			}
			throw new Exception("Reading the unique key failed.", e);
		} finally {

			if (session != null)
				session.close();
		}

		return customerToken;
	}

	public boolean updateCustomerToken(CustomerToken customerToken) throws Exception {

		Session session = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			customerToken = (CustomerToken) session.get(CustomerToken.class, customerToken.getCustTokenId());
			customerToken.setUpdateTime(new Date());
			session.getTransaction().commit();

		} catch (Exception e) {

			throw new Exception("Reading the customer token failed.", e);
		} finally {

			if (session != null)
				session.close();
		}

		return true;
	}

	public void saveUniqueKey(CustomerToken custtoken) throws Exception {

		Session session = null;

		try {

			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			Criteria criteria = session.createCriteria(CustomerToken.class)
					.setProjection(Projections.max("custTokenId"));

			Integer max = (Integer) criteria.uniqueResult();
			if (max != null) {
				custtoken.setCustTokenId(max + 1);
			} else {
				custtoken.setCustTokenId(1);
			}
			session.saveOrUpdate(custtoken);
			session.getTransaction().commit();

		} catch (Exception pEx) {

			throw new Exception("Creating the customer token unique key failed.", pEx);
		} finally {

			if (session != null) {
				session.close();
			}
		}
	}

	public UserSession getSessionToken(String userId, String deviceId) throws Exception {

		UserSession userSession = null;
		Session session = null;
		Criteria criteria = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			criteria = session.createCriteria(UserSession.class);
			criteria.add(Restrictions.eq("userId", userId.trim()));
			criteria.add(Restrictions.eq("deviceId", deviceId.trim()));
			userSession = (UserSession) criteria.uniqueResult();

			session.getTransaction().commit();
			
		} catch (Exception pEx) {
			
			throw new Exception("Reading user session failed.", pEx);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return userSession;
	}
	
	public void updateSessionToken(UserSession usersession) throws Exception {

		Session session = null;
		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			session.update(usersession);
			session.getTransaction().commit();
		} catch (Exception pEx) {
			
			throw new Exception("Updating user session failed.", pEx);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public void saveSession(UserSession sessiontoken) throws Exception {
		
		Session session = null;
		try {
			
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();
			session.save(sessiontoken);
			session.getTransaction().commit();

		} catch (PersistenceException pEx) {

			throw new Exception("Creating user session failed.", pEx);
		} finally {

			if (session != null) {
				session.close();
			}
		}
	}
}
