package com.ducont.core.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;

import com.ducont.core.Constants;
import com.ducont.core.dao.api.IHostLogDAO;
import com.ducont.core.model.HostLog;
import com.ducont.core.util.HibernateUtil;

public class HostLogDAO implements IHostLogDAO {

	@Override
	public void createHostLogRecord(HostLog hostLog) throws Exception {

		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			Criteria criteria = session.createCriteria(HostLog.class).setProjection(Projections.max("hostLogId"));
			Integer max = (Integer) criteria.uniqueResult();
			if (max != null) {
				hostLog.setHostLogId(max + 1);
			} else {
				hostLog.setHostLogId(1);
			}
			session.saveOrUpdate(hostLog);
			session.getTransaction().commit();
		} catch (Exception e) {

			throw new Exception("Adding host log failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public void updateHostLogRecord(HostLog hostLog) throws Exception {

		Session session = null;

		try {
			session = HibernateUtil.getSessionFactory(Constants.RESOURCES_CORE_HIBERNATE_CFG_XML).openSession();
			session.beginTransaction();

			session.update(hostLog);
			session.getTransaction().commit();
			
		} catch (Exception e) {

			throw new Exception("Updating host log failed.", e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}
