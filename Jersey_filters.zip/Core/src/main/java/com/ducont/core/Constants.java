package com.ducont.core;

import java.io.File;

public interface Constants {

	final String PROPERTIES_PATH = "c:" + File.separator + "Wallet_config" + File.separator + "Param" + File.separator;
	final String ENV_PROPERTIES_PATH = PROPERTIES_PATH + "Configuration";
	final String PROPERTIES_EXTENSION = ".properties";

	// Encryption
	final String MBS_SESSION_TOKEN = "ptoken";

	final String RESOURCES_CORE_HIBERNATE_CFG_XML = "/resources/core_hibernate.cfg.xml";
	final String RESOURCES_RECURRING_PAY_HIBERNATE_CFG_XML = "/resources/recurring_pay_hibernate.cfg.xml";
	final String RESOURCES_OFFER_PROMOCODES_HIBERNATE_CFG_XML = "/resources/offers_promocodes_hibernate.cfg.xml";
	final String RESOURCES_BILL_PAY_HIBERNATE_CFG_XML = "/resources/billpay_hibernate.cfg.xml";
	final String RESOURCES_QRCODE_HIBERNATE_CFG_XML = "/resources/qrcode_hibernate.cfg.xml";
	final String RESOURCES_SOCIAL_PAYMENT_HIBERNATE_CFG_XML = "/resources/social_payment_hibernate.cfg.xml";;

	final String SUCCESS_RETURN_VALUE = "ERR0";
	final String FAILURE_RETURN_VALUE = "ERR1";
	
	final int RECURRING_FUNDS_TRANSFER_SERVICE_ID = 234;
	final int RECURRING_FUNDS_TRANSFER_ADD_SERVICE_ID = 235;
	final int RECURRING_BILL_PAYMENT_SERVICE_ID = 236;
	final int RECURRING_BILL_PAYMENT_ADD_SERVICE_ID = 237;

}