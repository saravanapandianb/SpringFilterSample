package com.ducont.common.test;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ducont.core.dao.api.IWalletInfoDAO;
import com.ducont.core.dao.impl.WalletInfoDAO;
import com.ducont.core.model.Wallet;

public class WalletInfoTest {

	IWalletInfoDAO walletInfo = null;

	@Before
	public void setUp() throws Exception {

		walletInfo = new WalletInfoDAO();
	}

	@After
	public void tearDown() throws Exception {

		walletInfo = null;
	}

	@Test
	public void testGetBillPaymentDetails() {

		try {
			Wallet wallet = walletInfo.getWallet(1);
			assertTrue(wallet != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}
}
