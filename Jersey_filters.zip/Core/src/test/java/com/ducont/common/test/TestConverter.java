package com.ducont.common.test;

import com.ducont.core.util.ArabicConverter;

public class TestConverter {

	public static void main(String[] args) {

		ArabicConverter converter = new ArabicConverter();
		String commonMessage = "";
		commonMessage = converter.convertArabicToUTF8("فشل التحقق من صحة بروموكود تطبيق");
		System.out.println(commonMessage);
		String arabicmessage = converter.convertUTF8ToArabic("|*UTF8|" + commonMessage);
		System.out.println(arabicmessage);
	}
}
