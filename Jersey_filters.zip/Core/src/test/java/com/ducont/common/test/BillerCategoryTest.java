package com.ducont.common.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ducont.core.dao.api.IBillerCategory;
import com.ducont.core.dao.impl.BillerCategoryDAO;
import com.ducont.core.model.Biller;
import com.ducont.core.model.BillerCategory;

public class BillerCategoryTest {

	IBillerCategory billerCategory = null;

	@Before
	public void setUp() throws Exception {

		billerCategory = new BillerCategoryDAO();
	}

	@After
	public void tearDown() throws Exception {

		billerCategory = null;
	}

	@Test
	public void testGetBillerCategories() {

		try {

			List<BillerCategory> billers = billerCategory.getBillerCategories();
			assertTrue(billers != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}

	@Test
	public void testGetBillerCategory() {
		try {
			BillerCategory biller = billerCategory.getBillerCategory('D');
			assertTrue(biller != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}

	@Test
	public void testGetBiller() {
		try {
			Biller biller = billerCategory.getBiller(1);
			assertTrue(biller != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}

}
