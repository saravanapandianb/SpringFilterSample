package com.ducont.common.test;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ducont.core.dao.api.ISystemConfigDAO;
import com.ducont.core.dao.impl.SystemConfigDAO;
import com.ducont.core.model.SystemInfo;

public class SystemConfigTest {

	ISystemConfigDAO configInfo = null;

	@Before
	public void setUp() throws Exception {

		configInfo = new SystemConfigDAO();
	}

	@After
	public void tearDown() throws Exception {

		configInfo = null;
	}

	@Test
	public void testGetBillPaymentDetails() {

		try {

			SystemInfo systemInfo = configInfo.getSystemInfo("BILLER_WALLET_ID");
			assertTrue(systemInfo != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}
}
