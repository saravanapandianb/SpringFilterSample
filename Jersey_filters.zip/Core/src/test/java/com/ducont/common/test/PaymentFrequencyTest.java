package com.ducont.common.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ducont.core.dao.api.IPaymentFrequency;
import com.ducont.core.dao.impl.PaymentFrequencyDAO;
import com.ducont.core.model.PaymentFrequency;

public class PaymentFrequencyTest {

	IPaymentFrequency paymentFrequency = null;

	@Before
	public void setUp() throws Exception {

		paymentFrequency = new PaymentFrequencyDAO();
	}

	@After
	public void tearDown() throws Exception {

		paymentFrequency = null;
	}

	@Test
	public void testGetBillPaymentDetails() {
		try {

			List<PaymentFrequency> payFrequencies = paymentFrequency.getPaymentFrequency();
			assertTrue(payFrequencies != null);
		} catch (Exception e) {

			assertTrue(false);
		}
	}

}
